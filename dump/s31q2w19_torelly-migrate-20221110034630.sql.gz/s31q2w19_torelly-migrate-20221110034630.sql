# Migração da Base de Dados MySQL do WordPress
#
# Gerado: Thursday 10. November 2022 03:46 UTC
# Nome do Servidor: localhost
# Banco de Dados: `s31q2w19_torelly`
# URL: //localhost/torellybastos.com.br
# Path: /var/www/vhosts/agencias3.com.br/dev.agencias3.com.br/torellybastos.com.br
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, areas, attachment, banners, clientes, customize_changeset, equipe, gestao, nav_menu_item, page, post, wp_global_styles, wpcf7_contact_form
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Apagar qualquer tabela `wp_commentmeta` existente
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Estrutura da tabela `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_commentmeta`
#

#
# Fim do conteúdo da tabela `wp_commentmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_comments` existente
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Estrutura da tabela `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Um comentarista do WordPress', 'wapuu@wordpress.example', 'https://br.wordpress.org/', '', '2022-10-18 13:00:16', '2022-10-18 16:00:16', 'Oi, isto é um comentário.\nPara iniciar a moderar, editar e excluir comentários, visite a tela Comentários no painel.\nOs avatares dos comentaristas vêm do <a href="https://br.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# Fim do conteúdo da tabela `wp_comments`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_links` existente
#

DROP TABLE IF EXISTS `wp_links`;


#
# Estrutura da tabela `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_links`
#

#
# Fim do conteúdo da tabela `wp_links`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_options` existente
#

DROP TABLE IF EXISTS `wp_options`;


#
# Estrutura da tabela `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1659 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/torellybastos.com.br', 'yes'),
(2, 'home', 'http://localhost/torellybastos.com.br', 'yes'),
(3, 'blogname', 'Torelly Bastos', 'yes'),
(4, 'blogdescription', 'Só mais um site WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'suporte@s3digital.com.br', 'yes'),
(7, 'start_of_week', '0', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '9', 'yes'),
(23, 'date_format', 'j \\d\\e F \\d\\e Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'j \\d\\e F \\d\\e Y, H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:177:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"banners/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"banners/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"banners/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"banners/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"banners/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"banners/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"banners/([^/]+)/embed/?$";s:40:"index.php?banners=$matches[1]&embed=true";s:28:"banners/([^/]+)/trackback/?$";s:34:"index.php?banners=$matches[1]&tb=1";s:36:"banners/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?banners=$matches[1]&paged=$matches[2]";s:43:"banners/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?banners=$matches[1]&cpage=$matches[2]";s:32:"banners/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?banners=$matches[1]&page=$matches[2]";s:24:"banners/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"banners/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"banners/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"banners/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"banners/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"banners/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"equipe/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"equipe/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"equipe/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"equipe/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"equipe/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"equipe/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"equipe/([^/]+)/embed/?$";s:39:"index.php?equipe=$matches[1]&embed=true";s:27:"equipe/([^/]+)/trackback/?$";s:33:"index.php?equipe=$matches[1]&tb=1";s:35:"equipe/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?equipe=$matches[1]&paged=$matches[2]";s:42:"equipe/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?equipe=$matches[1]&cpage=$matches[2]";s:31:"equipe/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?equipe=$matches[1]&page=$matches[2]";s:23:"equipe/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"equipe/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"equipe/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"equipe/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"equipe/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"equipe/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"gestao/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"gestao/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"gestao/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"gestao/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"gestao/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"gestao/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"gestao/([^/]+)/embed/?$";s:39:"index.php?gestao=$matches[1]&embed=true";s:27:"gestao/([^/]+)/trackback/?$";s:33:"index.php?gestao=$matches[1]&tb=1";s:35:"gestao/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?gestao=$matches[1]&paged=$matches[2]";s:42:"gestao/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?gestao=$matches[1]&cpage=$matches[2]";s:31:"gestao/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?gestao=$matches[1]&page=$matches[2]";s:23:"gestao/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"gestao/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"gestao/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"gestao/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"gestao/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:29:"gestao/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"areas/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"areas/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"areas/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"areas/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"areas/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"areas/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"areas/([^/]+)/embed/?$";s:38:"index.php?areas=$matches[1]&embed=true";s:26:"areas/([^/]+)/trackback/?$";s:32:"index.php?areas=$matches[1]&tb=1";s:34:"areas/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?areas=$matches[1]&paged=$matches[2]";s:41:"areas/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?areas=$matches[1]&cpage=$matches[2]";s:30:"areas/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?areas=$matches[1]&page=$matches[2]";s:22:"areas/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"areas/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"areas/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"areas/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"areas/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"areas/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"clientes/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"clientes/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"clientes/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"clientes/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"clientes/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"clientes/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"clientes/([^/]+)/embed/?$";s:41:"index.php?clientes=$matches[1]&embed=true";s:29:"clientes/([^/]+)/trackback/?$";s:35:"index.php?clientes=$matches[1]&tb=1";s:37:"clientes/([^/]+)/page/?([0-9]{1,})/?$";s:48:"index.php?clientes=$matches[1]&paged=$matches[2]";s:44:"clientes/([^/]+)/comment-page-([0-9]{1,})/?$";s:48:"index.php?clientes=$matches[1]&cpage=$matches[2]";s:33:"clientes/([^/]+)(?:/([0-9]+))?/?$";s:47:"index.php?clientes=$matches[1]&page=$matches[2]";s:25:"clientes/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"clientes/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"clientes/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"clientes/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"clientes/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"clientes/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:56:"advanced-custom-fields-font-awesome/acf-font-awesome.php";i:1;s:41:"advanced-custom-fields-pro-master/acf.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:5:{i:0;s:106:"/var/www/vhosts/agencias3.com.br/dev.agencias3.com.br/torellybastos.com.br/wp-content/themes/s3/footer.php";i:2;s:106:"/var/www/vhosts/agencias3.com.br/dev.agencias3.com.br/torellybastos.com.br/wp-content/themes/s3/header.php";i:3;s:105:"/var/www/vhosts/agencias3.com.br/dev.agencias3.com.br/torellybastos.com.br/wp-content/themes/s3/style.css";i:4;s:113:"/var/www/vhosts/agencias3.com.br/dev.agencias3.com.br/torellybastos.com.br/wp-content/themes/s3/template-home.php";i:5;s:0:"";}', 'no'),
(40, 'template', 's3', 'yes'),
(41, 'stylesheet', 's3', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', 'America/Sao_Paulo', 'yes'),
(81, 'page_for_posts', '7', 'yes'),
(82, 'page_on_front', '6', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1681660815', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'pt_BR', 'yes'),
(103, 'user_count', '2', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:156:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Posts recentes</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:224:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Comentários</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Arquivos</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Categorias</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:7:{i:1668052817;a:5:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1668052833;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1668096016;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1668096033;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1668096035;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1668614417;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'nonce_key', 'MAh(cHT2i5f.Bh~e7|SV/*IIlK* tKt5]A1r!Lz-k3@^ZYE+52L,@!CmnT&||vxN', 'no'),
(117, 'nonce_salt', 'JB.ZnSNpeJ YGM&R+AdRfZoe8=w;G<]bz9~}L$xr<M4flajnNRvH&niEoq_]sj5l', 'no'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'recovery_keys', 'a:0:{}', 'yes'),
(123, 'https_detection_errors', 'a:0:{}', 'yes'),
(135, 'auth_key', 'zG~.(VK|N,d>N#<w3+iY_kW~;|{dqHc8B)AAB1?k9krl??N(L(CNn3/tpD;LC>B5', 'no'),
(136, 'auth_salt', 'X$7dEh,q%-95|cz.k@4bSy2VZS$WLOE+LU2G3eBX9Gmd(/TTWG({x!m7n+C;|*b)', 'no'),
(137, 'logged_in_key', '@2K(_AHx?ibxG2BD7f+6q#)AKFy: 9#)toM$[0AGBpnEv~U$CQf*:,)kSPw1;~D;', 'no'),
(138, 'logged_in_salt', '+3=9-K-&/?t}HuQ]|D,p{/3=mC}3DO(f!![jdC*CzqzZ2oRoA@=y=79tME4cQQN%', 'no'),
(153, 'can_compress_scripts', '1', 'no'),
(157, 'theme_mods_twentytwentytwo', 'a:2:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1666108842;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(158, 'current_theme', 'Agência S3', 'yes'),
(159, 'theme_mods_s3', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:3:{s:12:"menu-desktop";i:3;s:13:"menu-footer-1";i:4;s:13:"menu-footer-2";i:6;}}', 'yes'),
(160, 'theme_switched', '', 'yes'),
(163, 'recently_activated', 'a:0:{}', 'yes'),
(168, 'finished_updating_comment_type', '1', 'yes'),
(173, 'acf_version', '5.12.2', 'yes'),
(178, 'acffa_settings', 'a:2:{s:19:"acffa_major_version";i:6;s:20:"acffa_plugin_version";s:5:"4.0.4";}', 'no'),
(179, 'ACFFA_latest_version_timestamp', '1667496267', 'yes'),
(180, 'ACFFA_latest_version', '6.2.0', 'yes'),
(208, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(209, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(220, 'options_redes_sociais_0_icone', '{"style":"brands","id":"linkedin","label":"LinkedIn","unicode":"f08c"}', 'no'),
(221, '_options_redes_sociais_0_icone', 'field_634ed30424ad3', 'no'),
(222, 'options_redes_sociais_0_url', 'a:3:{s:5:"title";s:0:"";s:3:"url";s:69:"https://www.linkedin.com/company/torelly-bastos-advogados-associados/";s:6:"target";s:0:"";}', 'no'),
(223, '_options_redes_sociais_0_url', 'field_634ed30c24ad4', 'no'),
(224, 'options_redes_sociais_1_icone', '{"style":"brands","id":"square-facebook","label":"Facebook Square","unicode":"f082"}', 'no'),
(225, '_options_redes_sociais_1_icone', 'field_634ed30424ad3', 'no'),
(226, 'options_redes_sociais_1_url', 'a:3:{s:5:"title";s:0:"";s:3:"url";s:38:"https://www.facebook.com/torellybastos";s:6:"target";s:0:"";}', 'no'),
(227, '_options_redes_sociais_1_url', 'field_634ed30c24ad4', 'no'),
(228, 'options_redes_sociais_2_icone', '{"style":"brands","id":"square-instagram","label":"Instagram Square","unicode":"e055"}', 'no'),
(229, '_options_redes_sociais_2_icone', 'field_634ed30424ad3', 'no'),
(230, 'options_redes_sociais_2_url', 'a:3:{s:5:"title";s:0:"";s:3:"url";s:50:"https://www.instagram.com/torellybastos_advogados/";s:6:"target";s:0:"";}', 'no'),
(231, '_options_redes_sociais_2_url', 'field_634ed30c24ad4', 'no'),
(232, 'options_redes_sociais', '3', 'no'),
(233, '_options_redes_sociais', 'field_634ed2f124ad2', 'no'),
(234, 'options_informacoes_empresa_0_icone', '{"style":"solid","id":"phone-volume","label":"Phone Volume","unicode":"f2a0"}', 'no'),
(235, '_options_informacoes_empresa_0_icone', 'field_634ed33124ad7', 'no'),
(236, 'options_informacoes_empresa_0_url', 'a:3:{s:5:"title";s:14:"(51) 3092-7700";s:3:"url";s:1:"#";s:6:"target";s:0:"";}', 'no'),
(237, '_options_informacoes_empresa_0_url', 'field_634ed33b24ad8', 'no'),
(238, 'options_informacoes_empresa_1_icone', '{"style":"regular","id":"envelope","label":"Envelope","unicode":"f0e0"}', 'no'),
(239, '_options_informacoes_empresa_1_icone', 'field_634ed33124ad7', 'no'),
(240, 'options_informacoes_empresa_1_url', 'a:3:{s:5:"title";s:66:"                                torellybastos@torellybastos.com.br";s:3:"url";s:1:"#";s:6:"target";s:0:"";}', 'no'),
(241, '_options_informacoes_empresa_1_url', 'field_634ed33b24ad8', 'no'),
(242, 'options_informacoes_empresa_2_icone', '{"style":"solid","id":"location-dot","label":"Location dot","unicode":"f3c5"}', 'no'),
(243, '_options_informacoes_empresa_2_icone', 'field_634ed33124ad7', 'no'),
(244, 'options_informacoes_empresa_2_url', 'a:3:{s:5:"title";s:70:"Avenida Dom Pedro II, 1351, 3º Andar, Porto Alegre, Rio Grande do Sul";s:3:"url";s:1:"#";s:6:"target";s:0:"";}', 'no'),
(245, '_options_informacoes_empresa_2_url', 'field_634ed33b24ad8', 'no'),
(246, 'options_informacoes_empresa', '3', 'no'),
(247, '_options_informacoes_empresa', 'field_634ed32324ad6', 'no'),
(276, 'contato_fone', ' 51 3092.7700', 'yes'),
(281, 'contato_email', 'torellybastos@torellybastos.com.br', 'yes'),
(373, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1668051990;}', 'no'),
(439, 'nav_menu_options', 'a:1:{s:8:"auto_add";a:0:{}}', 'yes'),
(501, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(579, 'category_children', 'a:0:{}', 'yes'),
(704, 'wpcf7', 'a:2:{s:7:"version";s:5:"5.6.4";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1666545032;s:7:"version";s:5:"5.6.4";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(705, 'options_formulario', '[contact-form-7 id="80" title="Contato"]', 'no'),
(706, '_options_formulario', 'field_635575381808c', 'no'),
(711, 'secret_key', '|J.;!K5j6&>R1jEhs@w<2Iyd(wZuT?P6SBYg=EM&gKCa@OOhIC$88&<p_`eap7Ld', 'no'),
(748, 'secure_auth_key', 'L$o>-dw<.#6i<4BE c4 {#(W?uDXXV(rrk2;0`5:d&[tCNnlK9U.2BlS;OECWcPT', 'no'),
(749, 'secure_auth_salt', 'zWc&Z:<m@#/f$EN9Ng3%*0G1?m/l`5-u5K3^5zb/DZEYC]z]6i4&|;C]cue0Dy8x', 'no'),
(1034, 'options_topbar_0_icone', '{"style":"solid","id":"phone-volume","label":"Phone Volume","unicode":"f2a0"}', 'no'),
(1035, '_options_topbar_0_icone', 'field_63593b95b35cb', 'no'),
(1036, 'options_topbar_0_url', 'a:3:{s:5:"title";s:12:"51 3092.7700";s:3:"url";s:1:"#";s:6:"target";s:0:"";}', 'no'),
(1037, '_options_topbar_0_url', 'field_63593ba0b35cc', 'no'),
(1038, 'options_topbar_1_icone', '{"style":"regular","id":"envelope","label":"Envelope","unicode":"f0e0"}', 'no'),
(1039, '_options_topbar_1_icone', 'field_63593b95b35cb', 'no'),
(1040, 'options_topbar_1_url', 'a:3:{s:5:"title";s:34:"torellybastos@torellybastos.com.br";s:3:"url";s:1:"#";s:6:"target";s:0:"";}', 'no'),
(1041, '_options_topbar_1_url', 'field_63593ba0b35cc', 'no'),
(1042, 'options_topbar', '2', 'no'),
(1043, '_options_topbar', 'field_63593b78b35ca', 'no'),
(1427, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:24:"suporte@s3digital.com.br";s:7:"version";s:3:"6.1";s:9:"timestamp";i:1667487258;}', 'no') ;

#
# Fim do conteúdo da tabela `wp_options`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_postmeta` existente
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Estrutura da tabela `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=664 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(5, 6, '_edit_lock', '1668002124:1'),
(6, 7, '_edit_lock', '1666114216:1'),
(7, 6, '_wp_page_template', 'template-home.php'),
(8, 11, '_edit_last', '1'),
(9, 11, '_edit_lock', '1667211083:1'),
(10, 20, '_wp_trash_meta_status', 'publish'),
(11, 20, '_wp_trash_meta_time', '1666111265'),
(12, 21, '_wp_trash_meta_status', 'publish'),
(13, 21, '_wp_trash_meta_time', '1666111312'),
(16, 27, '_wp_attached_file', '2022/10/imagem-banner-blog.png'),
(17, 27, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2220;s:6:"height";i:600;s:4:"file";s:30:"2022/10/imagem-banner-blog.png";s:8:"filesize";i:1743591;s:5:"sizes";a:14:{s:6:"medium";a:5:{s:4:"file";s:29:"imagem-banner-blog-300x81.png";s:5:"width";i:300;s:6:"height";i:81;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:41183;}s:5:"large";a:5:{s:4:"file";s:31:"imagem-banner-blog-1024x277.png";s:5:"width";i:1024;s:6:"height";i:277;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:385621;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"imagem-banner-blog-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:35690;}s:12:"medium_large";a:5:{s:4:"file";s:30:"imagem-banner-blog-768x208.png";s:5:"width";i:768;s:6:"height";i:208;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:230057;}s:9:"1536x1536";a:5:{s:4:"file";s:31:"imagem-banner-blog-1536x415.png";s:5:"width";i:1536;s:6:"height";i:415;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:776771;}s:9:"2048x2048";a:5:{s:4:"file";s:31:"imagem-banner-blog-2048x554.png";s:5:"width";i:2048;s:6:"height";i:554;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1250941;}s:11:"admin-thumb";a:5:{s:4:"file";s:29:"imagem-banner-blog-100x27.png";s:5:"width";i:100;s:6:"height";i:27;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:5391;}s:7:"600x500";a:5:{s:4:"file";s:30:"imagem-banner-blog-600x500.png";s:5:"width";i:600;s:6:"height";i:500;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:349065;}s:4:"h400";a:5:{s:4:"file";s:31:"imagem-banner-blog-1480x400.png";s:5:"width";i:1480;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:738444;}i:0;a:5:{s:4:"file";s:31:"imagem-banner-blog-1200x324.png";s:5:"width";i:1200;s:6:"height";i:324;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:508797;}s:7:"360x180";a:5:{s:4:"file";s:30:"imagem-banner-blog-360x180.png";s:5:"width";i:360;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:96514;}s:7:"420x250";a:5:{s:4:"file";s:30:"imagem-banner-blog-420x250.png";s:5:"width";i:420;s:6:"height";i:250;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:146433;}s:4:"w160";a:5:{s:4:"file";s:29:"imagem-banner-blog-160x43.png";s:5:"width";i:160;s:6:"height";i:43;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12688;}s:7:"295x200";a:5:{s:4:"file";s:30:"imagem-banner-blog-295x200.png";s:5:"width";i:295;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:87718;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(18, 7, '_edit_last', '1'),
(19, 7, 'titulo_topo', 'Confira as Últimas Notícias do Blog'),
(20, 7, '_titulo_topo', 'field_634edd7b0cd36'),
(21, 7, 'banner_blog', '27'),
(22, 7, '_banner_blog', 'field_634edd89f6811'),
(23, 7, 'titulo_banner_blog', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod'),
(24, 7, '_titulo_banner_blog', 'field_634eddeaf6812'),
(25, 7, 'botao_banner_blog', 'a:3:{s:5:"title";s:18:"Confira a Matéria";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(26, 7, '_botao_banner_blog', 'field_634eddfbf6813'),
(27, 28, 'titulo_topo', '                        Confira as Últimas Notícias do Blog'),
(28, 28, '_titulo_topo', 'field_634edd7b0cd36'),
(29, 28, 'banner_blog', '27'),
(30, 28, '_banner_blog', 'field_634edd89f6811'),
(31, 28, 'titulo_banner_blog', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod'),
(32, 28, '_titulo_banner_blog', 'field_634eddeaf6812'),
(33, 28, 'botao_banner_blog', 'a:3:{s:5:"title";s:18:"Confira a Matéria";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(34, 28, '_botao_banner_blog', 'field_634eddfbf6813'),
(35, 29, 'titulo_topo', 'Confira as Últimas Notícias do Blog'),
(36, 29, '_titulo_topo', 'field_634edd7b0cd36'),
(37, 29, 'banner_blog', '27'),
(38, 29, '_banner_blog', 'field_634edd89f6811'),
(39, 29, 'titulo_banner_blog', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod'),
(40, 29, '_titulo_banner_blog', 'field_634eddeaf6812'),
(41, 29, 'botao_banner_blog', 'a:3:{s:5:"title";s:18:"Confira a Matéria";s:3:"url";s:1:"#";s:6:"target";s:0:"";}'),
(42, 29, '_botao_banner_blog', 'field_634eddfbf6813'),
(45, 32, '_menu_item_type', 'custom'),
(46, 32, '_menu_item_menu_item_parent', '0'),
(47, 32, '_menu_item_object_id', '32'),
(48, 32, '_menu_item_object', 'custom'),
(49, 32, '_menu_item_target', ''),
(50, 32, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(51, 32, '_menu_item_xfn', ''),
(52, 32, '_menu_item_url', '#banner'),
(53, 33, '_menu_item_type', 'custom'),
(54, 33, '_menu_item_menu_item_parent', '0'),
(55, 33, '_menu_item_object_id', '33'),
(56, 33, '_menu_item_object', 'custom'),
(57, 33, '_menu_item_target', ''),
(58, 33, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(59, 33, '_menu_item_xfn', ''),
(60, 33, '_menu_item_url', '#sobre'),
(61, 31, '_wp_trash_meta_status', 'publish'),
(62, 31, '_wp_trash_meta_time', '1666442139'),
(71, 34, '_wp_trash_meta_status', 'publish'),
(72, 34, '_wp_trash_meta_time', '1666442206'),
(88, 37, '_menu_item_type', 'custom'),
(89, 37, '_menu_item_menu_item_parent', '0'),
(90, 37, '_menu_item_object_id', '37'),
(91, 37, '_menu_item_object', 'custom'),
(92, 37, '_menu_item_target', ''),
(93, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(94, 37, '_menu_item_xfn', ''),
(95, 37, '_menu_item_url', '#banner'),
(96, 38, '_menu_item_type', 'custom'),
(97, 38, '_menu_item_menu_item_parent', '0'),
(98, 38, '_menu_item_object_id', '38'),
(99, 38, '_menu_item_object', 'custom'),
(100, 38, '_menu_item_target', ''),
(101, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(102, 38, '_menu_item_xfn', ''),
(103, 38, '_menu_item_url', '#sobre'),
(104, 36, '_wp_trash_meta_status', 'publish'),
(105, 36, '_wp_trash_meta_time', '1666442357'),
(106, 39, '_edit_lock', '1666444036:1'),
(107, 40, '_wp_attached_file', '2022/10/banner.png'),
(108, 40, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:680;s:4:"file";s:18:"2022/10/banner.png";s:8:"filesize";i:1036274;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:18:"banner-300x142.png";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:50595;}s:5:"large";a:5:{s:4:"file";s:19:"banner-1024x484.png";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:483012;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"banner-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:30587;}s:12:"medium_large";a:5:{s:4:"file";s:18:"banner-768x363.png";s:5:"width";i:768;s:6:"height";i:363;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:287360;}s:11:"admin-thumb";a:5:{s:4:"file";s:17:"banner-100x47.png";s:5:"width";i:100;s:6:"height";i:47;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7468;}s:7:"350x230";a:5:{s:4:"file";s:18:"banner-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:93127;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(111, 39, '_thumbnail_id', '40'),
(112, 1, 'tp_post_counter', '5'),
(113, 1, '_edit_lock', '1666532458:1'),
(116, 43, '_edit_last', '1'),
(117, 43, '_edit_lock', '1667573892:1'),
(118, 43, '_thumbnail_id', '188'),
(119, 44, '_edit_last', '1'),
(120, 44, '_edit_lock', '1667210079:1'),
(121, 49, '_wp_attached_file', '2022/10/galeria.png'),
(122, 49, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:350;s:6:"height";i:196;s:4:"file";s:19:"2022/10/galeria.png";s:8:"filesize";i:123951;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:19:"galeria-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:77802;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"galeria-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37728;}s:11:"admin-thumb";a:5:{s:4:"file";s:18:"galeria-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11418;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(123, 6, '_edit_last', '1'),
(124, 6, 'galeria_sobre', 'a:3:{i:0;s:2:"49";i:1;s:2:"82";i:2;s:3:"209";}'),
(125, 6, '_galeria_sobre', 'field_635565c9881a9'),
(126, 6, 'texto_1', 'A TORELLY BASTOS ADVOGADOS ASSOCIADOS tem uma trajetória de mais de vinte anos de dedicação no atendimento de clientes empresariais. Com atuação nacional, está sediada na cidade de Porto Alegre/RS, com excelente localização geográfica, situando-se em ponto estratégico e nobre da Capital, onde são concentrados os atos gerenciais e realizada a coordenação de todas as operações. Escritório sempre atualizado, com profissionais especializados, oportunizando excelentes resultados nas frentes de atuação.'),
(127, 6, '_texto_1', 'field_635565d4881aa'),
(128, 6, 'texto_2', 'Com recursos tecnológicos de ponta, possui uma estrutura organizacional e estratégica que permite estar preparado para o atendimento das mais diversas necessidades dos seus clientes, administrativas e judiciais. Referência no seguimento do Direito do Seguro, Previdência Privada, Responsabilidade Civil, Relações de Consumo, também atua no Direito Bancário, Trabalhista, Tributário, Recuperação Judicial e Ambiental.'),
(129, 6, '_texto_2', 'field_635565df881ab'),
(130, 52, 'galeria_sobre', 'a:1:{i:0;s:2:"49";}'),
(131, 52, '_galeria_sobre', 'field_635565c9881a9'),
(132, 52, 'texto_1', 'A TORELLY BASTOS ADVOGADOS ASSOCIADOS tem uma trajetória de mais de vinte anos de dedicação no atendimento de clientes empresariais. Com atuação nacional, está sediada na cidade de Porto Alegre/RS, com excelente localização geográfica, situando-se em ponto estratégico e nobre da Capital, onde são concentrados os atos gerenciais e realizada a coordenação de todas as operações. Escritório sempre atualizado, com profissionais especializados, oportunizando excelentes resultados nas frentes de atuação.'),
(133, 52, '_texto_1', 'field_635565d4881aa') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(134, 52, 'texto_2', 'Com recursos tecnológicos de ponta, possui uma estrutura organizacional e estratégica que permite estar preparado para o atendimento das mais diversas necessidades dos seus clientes, administrativas e judiciais. Referência no seguimento do Direito do Seguro, Previdência Privada, Responsabilidade Civil, Relações de Consumo, também atua no Direito Bancário, Trabalhista, Tributário, Recuperação Judicial e Ambiental.'),
(135, 52, '_texto_2', 'field_635565df881ab'),
(136, 53, 'galeria_sobre', 'a:1:{i:0;s:2:"49";}'),
(137, 53, '_galeria_sobre', 'field_635565c9881a9'),
(138, 53, 'texto_1', 'A TORELLY BASTOS ADVOGADOS ASSOCIADOS tem uma trajetória de mais de vinte anos de dedicação no atendimento de clientes empresariais. Com atuação nacional, está sediada na cidade de Porto Alegre/RS, com excelente localização geográfica, situando-se em ponto estratégico e nobre da Capital, onde são concentrados os atos gerenciais e realizada a coordenação de todas as operações. Escritório sempre atualizado, com profissionais especializados, oportunizando excelentes resultados nas frentes de atuação.'),
(139, 53, '_texto_1', 'field_635565d4881aa'),
(140, 53, 'texto_2', 'Com recursos tecnológicos de ponta, possui uma estrutura organizacional e estratégica que permite estar preparado para o atendimento das mais diversas necessidades dos seus clientes, administrativas e judiciais. Referência no seguimento do Direito do Seguro, Previdência Privada, Responsabilidade Civil, Relações de Consumo, também atua no Direito Bancário, Trabalhista, Tributário, Recuperação Judicial e Ambiental.'),
(141, 53, '_texto_2', 'field_635565df881ab'),
(142, 54, 'galeria_sobre', 'a:1:{i:0;s:2:"49";}'),
(143, 54, '_galeria_sobre', 'field_635565c9881a9'),
(144, 54, 'texto_1', 'A TORELLY BASTOS ADVOGADOS ASSOCIADOS tem uma trajetória de mais de vinte anos de dedicação no atendimento de clientes empresariais. Com atuação nacional, está sediada na cidade de Porto Alegre/RS, com excelente localização geográfica, situando-se em ponto estratégico e nobre da Capital, onde são concentrados os atos gerenciais e realizada a coordenação de todas as operações. Escritório sempre atualizado, com profissionais especializados, oportunizando excelentes resultados nas frentes de atuação.'),
(145, 54, '_texto_1', 'field_635565d4881aa'),
(146, 54, 'texto_2', 'Com recursos tecnológicos de ponta, possui uma estrutura organizacional e estratégica que permite estar preparado para o atendimento das mais diversas necessidades dos seus clientes, administrativas e judiciais. Referência no seguimento do Direito do Seguro, Previdência Privada, Responsabilidade Civil, Relações de Consumo, também atua no Direito Bancário, Trabalhista, Tributário, Recuperação Judicial e Ambiental.'),
(147, 54, '_texto_2', 'field_635565df881ab'),
(148, 6, 'icone_missao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(149, 6, '_icone_missao', 'field_635569ad53b6d'),
(150, 6, 'titulo_missao', 'MISSÃO'),
(151, 6, '_titulo_missao', 'field_6355698153b6b'),
(152, 6, 'texto_missao', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(153, 6, '_texto_missao', 'field_6355699a53b6c'),
(154, 6, 'icone_visao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(155, 6, '_icone_visao', 'field_635569c053b6e'),
(156, 6, 'titulo_visao', 'Visão'),
(157, 6, '_titulo_visao', 'field_635569c953b6f'),
(158, 6, 'texto_visao', 'Ser o escritório mais qualificado do país no segmento e o preferido dos seus públicos de interesse.'),
(159, 6, '_texto_visao', 'field_635569d253b70'),
(160, 6, 'icone_valores', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(161, 6, '_icone_valores', 'field_63556aaf53b71'),
(162, 6, 'titulo_valores', 'Valores'),
(163, 6, '_titulo_valores', 'field_63556b4d53b72'),
(164, 6, 'texto_valores', 'Atuação primada pela idoneidade, transparência, colaboração e prontidão para mudanças.'),
(165, 6, '_texto_valores', 'field_63556b6153b73'),
(166, 65, 'galeria_sobre', 'a:1:{i:0;s:2:"49";}'),
(167, 65, '_galeria_sobre', 'field_635565c9881a9'),
(168, 65, 'texto_1', 'A TORELLY BASTOS ADVOGADOS ASSOCIADOS tem uma trajetória de mais de vinte anos de dedicação no atendimento de clientes empresariais. Com atuação nacional, está sediada na cidade de Porto Alegre/RS, com excelente localização geográfica, situando-se em ponto estratégico e nobre da Capital, onde são concentrados os atos gerenciais e realizada a coordenação de todas as operações. Escritório sempre atualizado, com profissionais especializados, oportunizando excelentes resultados nas frentes de atuação.'),
(169, 65, '_texto_1', 'field_635565d4881aa'),
(170, 65, 'texto_2', 'Com recursos tecnológicos de ponta, possui uma estrutura organizacional e estratégica que permite estar preparado para o atendimento das mais diversas necessidades dos seus clientes, administrativas e judiciais. Referência no seguimento do Direito do Seguro, Previdência Privada, Responsabilidade Civil, Relações de Consumo, também atua no Direito Bancário, Trabalhista, Tributário, Recuperação Judicial e Ambiental.'),
(171, 65, '_texto_2', 'field_635565df881ab'),
(172, 65, 'icone_missao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(173, 65, '_icone_missao', 'field_635569ad53b6d'),
(174, 65, 'titulo_missao', 'MISSÃO'),
(175, 65, '_titulo_missao', 'field_6355698153b6b'),
(176, 65, 'texto_missao', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(177, 65, '_texto_missao', 'field_6355699a53b6c'),
(178, 65, 'icone_visao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(179, 65, '_icone_visao', 'field_635569c053b6e'),
(180, 65, 'titulo_visao', 'Visão'),
(181, 65, '_titulo_visao', 'field_635569c953b6f'),
(182, 65, 'texto_visao', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(183, 65, '_texto_visao', 'field_635569d253b70'),
(184, 65, 'icone_valores', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(185, 65, '_icone_valores', 'field_63556aaf53b71'),
(186, 65, 'titulo_valores', 'Valores'),
(187, 65, '_titulo_valores', 'field_63556b4d53b72'),
(188, 65, 'texto_valores', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(189, 65, '_texto_valores', 'field_63556b6153b73'),
(190, 66, '_edit_last', '1'),
(191, 66, '_edit_lock', '1667557525:1'),
(192, 69, '_edit_last', '1'),
(193, 69, '_edit_lock', '1666966906:1'),
(194, 70, '_wp_attached_file', '2022/10/equipe.png'),
(195, 70, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:278;s:6:"height";i:278;s:4:"file";s:18:"2022/10/equipe.png";s:8:"filesize";i:116927;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"equipe-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36051;}s:11:"admin-thumb";a:5:{s:4:"file";s:18:"equipe-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18410;}s:7:"350x230";a:5:{s:4:"file";s:18:"equipe-278x230.png";s:5:"width";i:278;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:83673;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(196, 69, '_thumbnail_id', '70'),
(197, 69, 'funcao', 'Sócio Fundador'),
(198, 69, '_funcao', 'field_63556db97d893'),
(199, 69, 'linkedin', 'https://www.linkedin.com/in/pedro-torelly-bastos-841078124/'),
(200, 69, '_linkedin', 'field_63556de305c26'),
(201, 72, '_edit_last', '1'),
(202, 72, '_edit_lock', '1667201143:1'),
(203, 74, '_edit_last', '1'),
(204, 74, '_edit_lock', '1666626823:1'),
(205, 74, 'icone', '{"style":"regular","id":"lightbulb","label":"Lightbulb","unicode":"f0eb"}'),
(206, 74, '_icone', 'field_635572181797d'),
(207, 75, '_edit_last', '1'),
(208, 75, '_edit_lock', '1667496110:1'),
(209, 75, 'icone', '{"style":"solid","id":"seedling","label":"Seedling","unicode":"f4d8"}'),
(210, 75, '_icone', 'field_635572181797d'),
(211, 76, '_edit_last', '1'),
(212, 76, '_edit_lock', '1666790689:1'),
(213, 77, '_wp_attached_file', '2022/10/hdi-seguros-logo-14FA67393D-seeklogo.com_.jpg'),
(214, 77, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:200;s:6:"height";i:200;s:4:"file";s:53:"2022/10/hdi-seguros-logo-14FA67393D-seeklogo.com_.jpg";s:8:"filesize";i:10394;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:53:"hdi-seguros-logo-14FA67393D-seeklogo.com_-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3227;}s:11:"admin-thumb";a:5:{s:4:"file";s:53:"hdi-seguros-logo-14FA67393D-seeklogo.com_-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2209;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(215, 76, '_thumbnail_id', '132'),
(216, 80, '_form', '<div class="mt-5">\n<div class="row mb-4">\n<div class="col-md-6">\n<div class="form-group mb-4 mb-md-0">\n[text* your-name class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary class:py-2 placeholder "Nome"]\n</div>\n</div>\n<div class="col-md-6">\n<div class="form-group">\n[email* your-email class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary class:py-2 placeholder "E-mail"]\n</div>\n</div>\n</div>\n<div class="row mb-4">\n<div class="col-md-6">\n<div class="form-group mb-4 mb-md-0">\n[tel* your-phone class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary class:py-2 placeholder "Telefone"]\n</div>\n</div>\n<div class="col-md-6">\n<div class="form-group">\n[text* your-subject class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary class:py-2 placeholder "Assunto"]\n</div>\n</div>\n</div>\n<div class="form-group mb-4">\n[textarea* your-message class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary placeholder "Mensagem"]\n</div>\n<!--\nREVISAR XD TEM CAMPOS DE CHCKBOX PARA RECEBER E-MAILS E ACEITE DE TERMOS\n-->\n<div>\n[submit class:btn class:btn-primary class:px-5 class:text-white class:rounded-0 "Enviar"]\n</div>\n</div>'),
(217, 80, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:40:"[_site_title] <suporte@s3digital.com.br>";s:9:"recipient";s:19:"[_site_admin_email]";s:4:"body";s:163:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(218, 80, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:40:"[_site_title] <suporte@s3digital.com.br>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:105:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on [_site_title] ([_site_url])";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(219, 80, '_messages', 'a:22:{s:12:"mail_sent_ok";s:44:"Obrigado pela sua mensagem. Já foi enviada.";s:12:"mail_sent_ng";s:85:"Ocorreu um erro ao tentar enviar sua mensagem. Por favor, tente novamente mais tarde.";s:16:"validation_error";s:70:"Um ou mais campos têm um erro. Por favor verifique e tente novamente.";s:4:"spam";s:85:"Ocorreu um erro ao tentar enviar sua mensagem. Por favor, tente novamente mais tarde.";s:12:"accept_terms";s:72:"Você deve aceitar os termos e condições antes de enviar sua mensagem.";s:16:"invalid_required";s:24:"O campo é obrigatório.";s:16:"invalid_too_long";s:23:"O campo é muito longo.";s:17:"invalid_too_short";s:23:"O campo é muito curto.";s:13:"upload_failed";s:51:"Ocorreu um erro desconhecido ao carregar o arquivo.";s:24:"upload_file_type_invalid";s:67:"Você não tem permissão para fazer upload de arquivos deste tipo.";s:21:"upload_file_too_large";s:26:"O arquivo é muito grande.";s:23:"upload_failed_php_error";s:38:"Ocorreu um erro ao carregar o arquivo.";s:12:"invalid_date";s:34:"O formato de data está incorreto.";s:14:"date_too_early";s:79:"O formato de data está incorreto. A data é anterior à mais antiga permitida.";s:13:"date_too_late";s:41:"A data é posterior à última permitida.";s:14:"invalid_number";s:34:"O formato do número é inválido.";s:16:"number_too_small";s:43:"O número é menor que o mínimo permitido.";s:16:"number_too_large";s:43:"O número é maior que o máximo permitido.";s:23:"quiz_answer_not_correct";s:35:"A resposta do quiz está incorreta.";s:13:"invalid_email";s:44:"O endereço de e-mail inserido é inválido.";s:11:"invalid_url";s:19:"O URL é inválido.";s:11:"invalid_tel";s:35:"O número de telefone é inválido.";}'),
(220, 80, '_additional_settings', ''),
(221, 80, '_locale', 'pt_BR'),
(222, 81, '_wp_attached_file', '2022/10/AHD_2021_0274_0016.png'),
(223, 81, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:350;s:6:"height";i:196;s:4:"file";s:30:"2022/10/AHD_2021_0274_0016.png";s:8:"filesize";i:163900;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:30:"AHD_2021_0274_0016-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:96201;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"AHD_2021_0274_0016-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44556;}s:11:"admin-thumb";a:5:{s:4:"file";s:29:"AHD_2021_0274_0016-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12431;}s:7:"278x278";a:5:{s:4:"file";s:30:"AHD_2021_0274_0016-278x196.png";s:5:"width";i:278;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:112310;}s:7:"200x200";a:5:{s:4:"file";s:30:"AHD_2021_0274_0016-200x196.png";s:5:"width";i:200;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:80884;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(224, 82, '_wp_attached_file', '2022/10/AHA_2015_003_0020.png'),
(225, 82, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:350;s:6:"height";i:196;s:4:"file";s:29:"2022/10/AHA_2015_003_0020.png";s:8:"filesize";i:146345;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:29:"AHA_2015_003_0020-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:99413;}s:9:"thumbnail";a:5:{s:4:"file";s:29:"AHA_2015_003_0020-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45886;}s:11:"admin-thumb";a:5:{s:4:"file";s:28:"AHA_2015_003_0020-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12498;}s:7:"278x278";a:5:{s:4:"file";s:29:"AHA_2015_003_0020-278x196.png";s:5:"width";i:278;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:114190;}s:7:"200x200";a:5:{s:4:"file";s:29:"AHA_2015_003_0020-200x196.png";s:5:"width";i:200;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:83167;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(226, 83, 'galeria_sobre', 'a:3:{i:0;s:2:"49";i:1;s:2:"81";i:2;s:2:"82";}'),
(227, 83, '_galeria_sobre', 'field_635565c9881a9'),
(228, 83, 'texto_1', 'A TORELLY BASTOS ADVOGADOS ASSOCIADOS tem uma trajetória de mais de vinte anos de dedicação no atendimento de clientes empresariais. Com atuação nacional, está sediada na cidade de Porto Alegre/RS, com excelente localização geográfica, situando-se em ponto estratégico e nobre da Capital, onde são concentrados os atos gerenciais e realizada a coordenação de todas as operações. Escritório sempre atualizado, com profissionais especializados, oportunizando excelentes resultados nas frentes de atuação.'),
(229, 83, '_texto_1', 'field_635565d4881aa'),
(230, 83, 'texto_2', 'Com recursos tecnológicos de ponta, possui uma estrutura organizacional e estratégica que permite estar preparado para o atendimento das mais diversas necessidades dos seus clientes, administrativas e judiciais. Referência no seguimento do Direito do Seguro, Previdência Privada, Responsabilidade Civil, Relações de Consumo, também atua no Direito Bancário, Trabalhista, Tributário, Recuperação Judicial e Ambiental.'),
(231, 83, '_texto_2', 'field_635565df881ab'),
(232, 83, 'icone_missao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(233, 83, '_icone_missao', 'field_635569ad53b6d') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(234, 83, 'titulo_missao', 'MISSÃO'),
(235, 83, '_titulo_missao', 'field_6355698153b6b'),
(236, 83, 'texto_missao', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(237, 83, '_texto_missao', 'field_6355699a53b6c'),
(238, 83, 'icone_visao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(239, 83, '_icone_visao', 'field_635569c053b6e'),
(240, 83, 'titulo_visao', 'Visão'),
(241, 83, '_titulo_visao', 'field_635569c953b6f'),
(242, 83, 'texto_visao', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(243, 83, '_texto_visao', 'field_635569d253b70'),
(244, 83, 'icone_valores', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(245, 83, '_icone_valores', 'field_63556aaf53b71'),
(246, 83, 'titulo_valores', 'Valores'),
(247, 83, '_titulo_valores', 'field_63556b4d53b72'),
(248, 83, 'texto_valores', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(249, 83, '_texto_valores', 'field_63556b6153b73'),
(252, 86, '_wp_attached_file', '2022/10/Imagem-Banner_02.png'),
(253, 86, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:680;s:4:"file";s:28:"2022/10/Imagem-Banner_02.png";s:8:"filesize";i:938893;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:28:"Imagem-Banner_02-300x142.png";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:61811;}s:5:"large";a:5:{s:4:"file";s:29:"Imagem-Banner_02-1024x484.png";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:480132;}s:9:"thumbnail";a:5:{s:4:"file";s:28:"Imagem-Banner_02-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:35389;}s:12:"medium_large";a:5:{s:4:"file";s:28:"Imagem-Banner_02-768x363.png";s:5:"width";i:768;s:6:"height";i:363;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:280107;}s:11:"admin-thumb";a:5:{s:4:"file";s:27:"Imagem-Banner_02-100x47.png";s:5:"width";i:100;s:6:"height";i:47;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8859;}s:7:"350x230";a:5:{s:4:"file";s:28:"Imagem-Banner_02-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:110551;}s:7:"278x278";a:5:{s:4:"file";s:28:"Imagem-Banner_02-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:107182;}s:7:"200x200";a:5:{s:4:"file";s:28:"Imagem-Banner_02-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:57335;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(254, 84, '_edit_last', '1'),
(255, 84, '_edit_lock', '1666966572:1'),
(256, 84, '_thumbnail_id', '203'),
(257, 88, 'galeria_sobre', 'a:3:{i:0;s:2:"49";i:1;s:2:"81";i:2;s:2:"82";}'),
(258, 88, '_galeria_sobre', 'field_635565c9881a9'),
(259, 88, 'texto_1', 'A TORELLY BASTOS ADVOGADOS ASSOCIADOS tem uma trajetória de mais de vinte anos de dedicação no atendimento de clientes empresariais. Com atuação nacional, está sediada na cidade de Porto Alegre/RS, com excelente localização geográfica, situando-se em ponto estratégico e nobre da Capital, onde são concentrados os atos gerenciais e realizada a coordenação de todas as operações. Escritório sempre atualizado, com profissionais especializados, oportunizando excelentes resultados nas frentes de atuação.'),
(260, 88, '_texto_1', 'field_635565d4881aa'),
(261, 88, 'texto_2', 'Com recursos tecnológicos de ponta, possui uma estrutura organizacional e estratégica que permite estar preparado para o atendimento das mais diversas necessidades dos seus clientes, administrativas e judiciais. Referência no seguimento do Direito do Seguro, Previdência Privada, Responsabilidade Civil, Relações de Consumo, também atua no Direito Bancário, Trabalhista, Tributário, Recuperação Judicial e Ambiental.'),
(262, 88, '_texto_2', 'field_635565df881ab'),
(263, 88, 'icone_missao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(264, 88, '_icone_missao', 'field_635569ad53b6d'),
(265, 88, 'titulo_missao', 'MISSÃO'),
(266, 88, '_titulo_missao', 'field_6355698153b6b'),
(267, 88, 'texto_missao', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(268, 88, '_texto_missao', 'field_6355699a53b6c'),
(269, 88, 'icone_visao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(270, 88, '_icone_visao', 'field_635569c053b6e'),
(271, 88, 'titulo_visao', 'Visão'),
(272, 88, '_titulo_visao', 'field_635569c953b6f'),
(273, 88, 'texto_visao', 'Ser o escritório mais qualificado do país no segmento e o preferido dos seus públicos de interesse.'),
(274, 88, '_texto_visao', 'field_635569d253b70'),
(275, 88, 'icone_valores', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(276, 88, '_icone_valores', 'field_63556aaf53b71'),
(277, 88, 'titulo_valores', 'Valores'),
(278, 88, '_titulo_valores', 'field_63556b4d53b72'),
(279, 88, 'texto_valores', 'Atuação primada pela idoneidade, transparência, colaboração e prontidão para mudanças.'),
(280, 88, '_texto_valores', 'field_63556b6153b73'),
(281, 89, '_edit_last', '1'),
(282, 89, '_edit_lock', '1666966932:1'),
(283, 69, 'reverse', '0'),
(284, 69, '_reverse', 'field_6355712236b49'),
(285, 90, '_wp_attached_file', '2022/10/1657376859522-1.png'),
(286, 90, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:278;s:6:"height";i:278;s:4:"file";s:27:"2022/10/1657376859522-1.png";s:8:"filesize";i:116774;s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:27:"1657376859522-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36343;}s:11:"admin-thumb";a:5:{s:4:"file";s:27:"1657376859522-1-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18472;}s:7:"350x230";a:5:{s:4:"file";s:27:"1657376859522-1-278x230.png";s:5:"width";i:278;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:83659;}s:7:"200x200";a:5:{s:4:"file";s:27:"1657376859522-1-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:58698;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(287, 91, '_wp_attached_file', '2022/10/1657376859522-1@2x.png'),
(288, 91, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:556;s:6:"height";i:556;s:4:"file";s:30:"2022/10/1657376859522-1@2x.png";s:8:"filesize";i:112549;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:30:"1657376859522-1@2x-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:115464;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"1657376859522-1@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37077;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"1657376859522-1@2x-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18842;}s:7:"350x230";a:5:{s:4:"file";s:30:"1657376859522-1@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:102191;}s:7:"278x278";a:5:{s:4:"file";s:30:"1657376859522-1@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:94590;}s:7:"200x200";a:5:{s:4:"file";s:30:"1657376859522-1@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:61700;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(289, 92, '_wp_attached_file', '2022/10/1657376859522-2.png'),
(290, 92, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:278;s:6:"height";i:278;s:4:"file";s:27:"2022/10/1657376859522-2.png";s:8:"filesize";i:160582;s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:27:"1657376859522-2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:38869;}s:11:"admin-thumb";a:5:{s:4:"file";s:27:"1657376859522-2-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19007;}s:7:"350x230";a:5:{s:4:"file";s:27:"1657376859522-2-278x230.png";s:5:"width";i:278;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:108062;}s:7:"200x200";a:5:{s:4:"file";s:27:"1657376859522-2-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:64854;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(291, 93, '_wp_attached_file', '2022/10/1657376859522-2@2x.png'),
(292, 93, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:556;s:6:"height";i:556;s:4:"file";s:30:"2022/10/1657376859522-2@2x.png";s:8:"filesize";i:522160;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:30:"1657376859522-2@2x-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:136752;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"1657376859522-2@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:39224;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"1657376859522-2@2x-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19035;}s:7:"350x230";a:5:{s:4:"file";s:30:"1657376859522-2@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:119465;}s:7:"278x278";a:5:{s:4:"file";s:30:"1657376859522-2@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:123163;}s:7:"200x200";a:5:{s:4:"file";s:30:"1657376859522-2@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:65883;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(293, 94, '_wp_attached_file', '2022/10/1657376859522-3.png'),
(294, 94, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:278;s:6:"height";i:278;s:4:"file";s:27:"2022/10/1657376859522-3.png";s:8:"filesize";i:133817;s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:27:"1657376859522-3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:34332;}s:11:"admin-thumb";a:5:{s:4:"file";s:27:"1657376859522-3-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16330;}s:7:"350x230";a:5:{s:4:"file";s:27:"1657376859522-3-278x230.png";s:5:"width";i:278;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:100630;}s:7:"200x200";a:5:{s:4:"file";s:27:"1657376859522-3-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:58104;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(295, 95, '_wp_attached_file', '2022/10/1657376859522-3@2x.png'),
(296, 95, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:556;s:6:"height";i:556;s:4:"file";s:30:"2022/10/1657376859522-3@2x.png";s:8:"filesize";i:470348;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:30:"1657376859522-3@2x-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:127158;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"1657376859522-3@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:34527;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"1657376859522-3@2x-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16314;}s:7:"350x230";a:5:{s:4:"file";s:30:"1657376859522-3@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:116926;}s:7:"278x278";a:5:{s:4:"file";s:30:"1657376859522-3@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:114416;}s:7:"200x200";a:5:{s:4:"file";s:30:"1657376859522-3@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:58975;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(297, 96, '_wp_attached_file', '2022/10/1657376859522-4.png'),
(298, 96, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:278;s:6:"height";i:278;s:4:"file";s:27:"2022/10/1657376859522-4.png";s:8:"filesize";i:145447;s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:27:"1657376859522-4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37979;}s:11:"admin-thumb";a:5:{s:4:"file";s:27:"1657376859522-4-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18203;}s:7:"350x230";a:5:{s:4:"file";s:27:"1657376859522-4-278x230.png";s:5:"width";i:278;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:101695;}s:7:"200x200";a:5:{s:4:"file";s:27:"1657376859522-4-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:64057;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(299, 97, '_wp_attached_file', '2022/10/1657376859522-4@2x.png'),
(300, 97, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:556;s:6:"height";i:556;s:4:"file";s:30:"2022/10/1657376859522-4@2x.png";s:8:"filesize";i:471624;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:30:"1657376859522-4@2x-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:134150;}s:9:"thumbnail";a:5:{s:4:"file";s:30:"1657376859522-4@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37920;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"1657376859522-4@2x-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18203;}s:7:"350x230";a:5:{s:4:"file";s:30:"1657376859522-4@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:116675;}s:7:"278x278";a:5:{s:4:"file";s:30:"1657376859522-4@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:116069;}s:7:"200x200";a:5:{s:4:"file";s:30:"1657376859522-4@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:64127;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(301, 98, '_wp_attached_file', '2022/10/1657376859522.png'),
(302, 98, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:278;s:6:"height";i:278;s:4:"file";s:25:"2022/10/1657376859522.png";s:8:"filesize";i:100407;s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:25:"1657376859522-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:33482;}s:11:"admin-thumb";a:5:{s:4:"file";s:25:"1657376859522-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16707;}s:7:"350x230";a:5:{s:4:"file";s:25:"1657376859522-278x230.png";s:5:"width";i:278;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:72411;}s:7:"200x200";a:5:{s:4:"file";s:25:"1657376859522-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:54523;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(303, 99, '_wp_attached_file', '2022/10/1657376859522@2x.png'),
(304, 99, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:556;s:6:"height";i:556;s:4:"file";s:28:"2022/10/1657376859522@2x.png";s:8:"filesize";i:99956;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:28:"1657376859522@2x-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:111490;}s:9:"thumbnail";a:5:{s:4:"file";s:28:"1657376859522@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:34172;}s:11:"admin-thumb";a:5:{s:4:"file";s:28:"1657376859522@2x-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:17085;}s:7:"350x230";a:5:{s:4:"file";s:28:"1657376859522@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:98761;}s:7:"278x278";a:5:{s:4:"file";s:28:"1657376859522@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:79875;}s:7:"200x200";a:5:{s:4:"file";s:28:"1657376859522@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:58077;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(305, 100, '_wp_attached_file', '2022/10/AdobeStock_399303485.png'),
(306, 100, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1464;s:6:"height";i:724;s:4:"file";s:32:"2022/10/AdobeStock_399303485.png";s:8:"filesize";i:1017682;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:32:"AdobeStock_399303485-300x148.png";s:5:"width";i:300;s:6:"height";i:148;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45795;}s:5:"large";a:5:{s:4:"file";s:33:"AdobeStock_399303485-1024x506.png";s:5:"width";i:1024;s:6:"height";i:506;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:429312;}s:9:"thumbnail";a:5:{s:4:"file";s:32:"AdobeStock_399303485-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:24622;}s:12:"medium_large";a:5:{s:4:"file";s:32:"AdobeStock_399303485-768x380.png";s:5:"width";i:768;s:6:"height";i:380;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:251103;}s:11:"admin-thumb";a:5:{s:4:"file";s:31:"AdobeStock_399303485-100x49.png";s:5:"width";i:100;s:6:"height";i:49;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6725;}s:7:"350x230";a:5:{s:4:"file";s:32:"AdobeStock_399303485-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:80033;}s:7:"278x278";a:5:{s:4:"file";s:32:"AdobeStock_399303485-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:76401;}s:7:"200x200";a:5:{s:4:"file";s:32:"AdobeStock_399303485-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:41371;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(307, 101, '_wp_attached_file', '2022/10/AdobeStock_399303485@2x.png'),
(308, 101, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2928;s:6:"height";i:1448;s:4:"file";s:35:"2022/10/AdobeStock_399303485@2x.png";s:8:"filesize";i:4105389;s:5:"sizes";a:11:{s:6:"medium";a:5:{s:4:"file";s:35:"AdobeStock_399303485@2x-300x148.png";s:5:"width";i:300;s:6:"height";i:148;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44483;}s:5:"large";a:5:{s:4:"file";s:36:"AdobeStock_399303485@2x-1024x506.png";s:5:"width";i:1024;s:6:"height";i:506;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:425804;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"AdobeStock_399303485@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23923;}s:12:"medium_large";a:5:{s:4:"file";s:35:"AdobeStock_399303485@2x-768x380.png";s:5:"width";i:768;s:6:"height";i:380;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:244001;}s:9:"1536x1536";a:5:{s:4:"file";s:36:"AdobeStock_399303485@2x-1536x760.png";s:5:"width";i:1536;s:6:"height";i:760;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:935716;}s:9:"2048x2048";a:5:{s:4:"file";s:37:"AdobeStock_399303485@2x-2048x1013.png";s:5:"width";i:2048;s:6:"height";i:1013;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1662746;}s:11:"admin-thumb";a:5:{s:4:"file";s:34:"AdobeStock_399303485@2x-100x49.png";s:5:"width";i:100;s:6:"height";i:49;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6494;}s:7:"350x230";a:5:{s:4:"file";s:35:"AdobeStock_399303485@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:76973;}s:8:"1600x768";a:5:{s:4:"file";s:36:"AdobeStock_399303485@2x-1600x768.png";s:5:"width";i:1600;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1046599;}s:7:"278x278";a:5:{s:4:"file";s:35:"AdobeStock_399303485@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:73323;}s:7:"200x200";a:5:{s:4:"file";s:35:"AdobeStock_399303485@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:39785;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(309, 102, '_wp_attached_file', '2022/10/AHA_2015_003_0020-1.png'),
(310, 102, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:255;s:6:"height";i:168;s:4:"file";s:31:"2022/10/AHA_2015_003_0020-1.png";s:8:"filesize";i:95904;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46568;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"AHA_2015_003_0020-1-100x66.png";s:5:"width";i:100;s:6:"height";i:66;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14722;}s:7:"200x200";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-1-200x168.png";s:5:"width";i:200;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:74397;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(311, 103, '_wp_attached_file', '2022/10/AHA_2015_003_0020-1@2x.png'),
(312, 103, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:510;s:6:"height";i:336;s:4:"file";s:34:"2022/10/AHA_2015_003_0020-1@2x.png";s:8:"filesize";i:345757;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-1@2x-300x198.png";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:115432;}s:9:"thumbnail";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-1@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45444;}s:11:"admin-thumb";a:5:{s:4:"file";s:33:"AHA_2015_003_0020-1@2x-100x66.png";s:5:"width";i:100;s:6:"height";i:66;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14404;}s:7:"350x230";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-1@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:153458;}s:7:"278x278";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-1@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:145371;}s:7:"200x200";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-1@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:78075;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(313, 104, '_wp_attached_file', '2022/10/AHA_2015_003_0020-2.png'),
(314, 104, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:255;s:6:"height";i:168;s:4:"file";s:31:"2022/10/AHA_2015_003_0020-2.png";s:8:"filesize";i:95904;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46568;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"AHA_2015_003_0020-2-100x66.png";s:5:"width";i:100;s:6:"height";i:66;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14722;}s:7:"200x200";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-2-200x168.png";s:5:"width";i:200;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:74397;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(315, 105, '_wp_attached_file', '2022/10/AHA_2015_003_0020-2@2x.png'),
(316, 105, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:510;s:6:"height";i:336;s:4:"file";s:34:"2022/10/AHA_2015_003_0020-2@2x.png";s:8:"filesize";i:345757;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-2@2x-300x198.png";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:115432;}s:9:"thumbnail";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-2@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45444;}s:11:"admin-thumb";a:5:{s:4:"file";s:33:"AHA_2015_003_0020-2@2x-100x66.png";s:5:"width";i:100;s:6:"height";i:66;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14404;}s:7:"350x230";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-2@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:153458;}s:7:"278x278";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-2@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:145371;}s:7:"200x200";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-2@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:78075;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(317, 106, '_wp_attached_file', '2022/10/AHA_2015_003_0020-3.png'),
(318, 106, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:350;s:6:"height";i:196;s:4:"file";s:31:"2022/10/AHA_2015_003_0020-3.png";s:8:"filesize";i:146345;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-3-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:99413;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-3-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45886;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"AHA_2015_003_0020-3-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12498;}s:7:"278x278";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-3-278x196.png";s:5:"width";i:278;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:114190;}s:7:"200x200";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-3-200x196.png";s:5:"width";i:200;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:83167;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(319, 107, '_wp_attached_file', '2022/10/AHA_2015_003_0020-3@2x.png'),
(320, 107, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:700;s:6:"height";i:392;s:4:"file";s:34:"2022/10/AHA_2015_003_0020-3@2x.png";s:8:"filesize";i:519017;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-3@2x-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:97701;}s:9:"thumbnail";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-3@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45103;}s:11:"admin-thumb";a:5:{s:4:"file";s:33:"AHA_2015_003_0020-3@2x-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12328;}s:7:"350x230";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-3@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:150467;}s:7:"278x278";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-3@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:142307;}s:7:"200x200";a:5:{s:4:"file";s:34:"AHA_2015_003_0020-3@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:76922;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(321, 108, '_wp_attached_file', '2022/10/AHA_2015_003_0020-4.png'),
(322, 108, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:255;s:6:"height";i:168;s:4:"file";s:31:"2022/10/AHA_2015_003_0020-4.png";s:8:"filesize";i:95904;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46568;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"AHA_2015_003_0020-4-100x66.png";s:5:"width";i:100;s:6:"height";i:66;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14722;}s:7:"200x200";a:5:{s:4:"file";s:31:"AHA_2015_003_0020-4-200x168.png";s:5:"width";i:200;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:74397;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(323, 109, '_wp_attached_file', '2022/10/AHA_2015_003_0020@2x.png'),
(324, 109, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:510;s:6:"height";i:336;s:4:"file";s:32:"2022/10/AHA_2015_003_0020@2x.png";s:8:"filesize";i:345757;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:32:"AHA_2015_003_0020@2x-300x198.png";s:5:"width";i:300;s:6:"height";i:198;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:115432;}s:9:"thumbnail";a:5:{s:4:"file";s:32:"AHA_2015_003_0020@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45444;}s:11:"admin-thumb";a:5:{s:4:"file";s:31:"AHA_2015_003_0020@2x-100x66.png";s:5:"width";i:100;s:6:"height";i:66;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14404;}s:7:"350x230";a:5:{s:4:"file";s:32:"AHA_2015_003_0020@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:153458;}s:7:"278x278";a:5:{s:4:"file";s:32:"AHA_2015_003_0020@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:145371;}s:7:"200x200";a:5:{s:4:"file";s:32:"AHA_2015_003_0020@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:78075;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(325, 110, '_wp_attached_file', '2022/10/AHD_2021_0274_0016-1.png'),
(326, 110, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:350;s:6:"height";i:196;s:4:"file";s:32:"2022/10/AHD_2021_0274_0016-1.png";s:8:"filesize";i:163900;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:32:"AHD_2021_0274_0016-1-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:96201;}s:9:"thumbnail";a:5:{s:4:"file";s:32:"AHD_2021_0274_0016-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44556;}s:11:"admin-thumb";a:5:{s:4:"file";s:31:"AHD_2021_0274_0016-1-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12431;}s:7:"278x278";a:5:{s:4:"file";s:32:"AHD_2021_0274_0016-1-278x196.png";s:5:"width";i:278;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:112310;}s:7:"200x200";a:5:{s:4:"file";s:32:"AHD_2021_0274_0016-1-200x196.png";s:5:"width";i:200;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:80884;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(327, 111, '_wp_attached_file', '2022/10/AHD_2021_0274_0016@2x.png'),
(328, 111, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:700;s:6:"height";i:392;s:4:"file";s:33:"2022/10/AHD_2021_0274_0016@2x.png";s:8:"filesize";i:576794;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:33:"AHD_2021_0274_0016@2x-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:95798;}s:9:"thumbnail";a:5:{s:4:"file";s:33:"AHD_2021_0274_0016@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44178;}s:11:"admin-thumb";a:5:{s:4:"file";s:32:"AHD_2021_0274_0016@2x-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12377;}s:7:"350x230";a:5:{s:4:"file";s:33:"AHD_2021_0274_0016@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:145611;}s:7:"278x278";a:5:{s:4:"file";s:33:"AHD_2021_0274_0016@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:135332;}s:7:"200x200";a:5:{s:4:"file";s:33:"AHD_2021_0274_0016@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:74590;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(329, 112, '_wp_attached_file', '2022/10/Akad-Seguros.png'),
(330, 112, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:95;s:6:"height";i:41;s:4:"file";s:24:"2022/10/Akad-Seguros.png";s:8:"filesize";i:3120;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(331, 113, '_wp_attached_file', '2022/10/Akad-Seguros@2x.png'),
(332, 113, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:190;s:6:"height";i:82;s:4:"file";s:27:"2022/10/Akad-Seguros@2x.png";s:8:"filesize";i:5126;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:26:"Akad-Seguros@2x-150x82.png";s:5:"width";i:150;s:6:"height";i:82;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3817;}s:11:"admin-thumb";a:5:{s:4:"file";s:26:"Akad-Seguros@2x-100x43.png";s:5:"width";i:100;s:6:"height";i:43;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4580;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(333, 114, '_wp_attached_file', '2022/10/ALFA-SEGURADORA.png'),
(334, 114, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:120;s:6:"height";i:131;s:4:"file";s:27:"2022/10/ALFA-SEGURADORA.png";s:8:"filesize";i:18231;s:5:"sizes";a:1:{s:11:"admin-thumb";a:5:{s:4:"file";s:27:"ALFA-SEGURADORA-100x109.png";s:5:"width";i:100;s:6:"height";i:109;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:15842;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(335, 115, '_wp_attached_file', '2022/10/ALFA-SEGURADORA@2x.png') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(336, 115, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:240;s:6:"height";i:262;s:4:"file";s:30:"2022/10/ALFA-SEGURADORA@2x.png";s:8:"filesize";i:61090;s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:30:"ALFA-SEGURADORA@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:27751;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"ALFA-SEGURADORA@2x-100x109.png";s:5:"width";i:100;s:6:"height";i:109;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16021;}s:7:"350x230";a:5:{s:4:"file";s:30:"ALFA-SEGURADORA@2x-240x230.png";s:5:"width";i:240;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:46321;}s:7:"200x200";a:5:{s:4:"file";s:30:"ALFA-SEGURADORA@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:43759;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(337, 116, '_wp_attached_file', '2022/10/Banco-Alfa.png'),
(338, 116, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:110;s:6:"height";i:110;s:4:"file";s:22:"2022/10/Banco-Alfa.png";s:8:"filesize";i:16139;s:5:"sizes";a:1:{s:11:"admin-thumb";a:5:{s:4:"file";s:22:"Banco-Alfa-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:13665;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(339, 117, '_wp_attached_file', '2022/10/Banco-Alfa@2x.png'),
(340, 117, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:220;s:6:"height";i:220;s:4:"file";s:25:"2022/10/Banco-Alfa@2x.png";s:8:"filesize";i:52088;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:25:"Banco-Alfa@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28291;}s:11:"admin-thumb";a:5:{s:4:"file";s:25:"Banco-Alfa@2x-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:13050;}s:7:"200x200";a:5:{s:4:"file";s:25:"Banco-Alfa@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:43658;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(341, 118, '_wp_attached_file', '2022/10/BERKLEY.png'),
(342, 118, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:183;s:6:"height";i:56;s:4:"file";s:19:"2022/10/BERKLEY.png";s:8:"filesize";i:11924;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"BERKLEY-150x56.png";s:5:"width";i:150;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:10440;}s:11:"admin-thumb";a:5:{s:4:"file";s:18:"BERKLEY-100x31.png";s:5:"width";i:100;s:6:"height";i:31;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4864;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(343, 119, '_wp_attached_file', '2022/10/BERKLEY@2x.png'),
(344, 119, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:366;s:6:"height";i:112;s:4:"file";s:22:"2022/10/BERKLEY@2x.png";s:8:"filesize";i:36609;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:21:"BERKLEY@2x-300x92.png";s:5:"width";i:300;s:6:"height";i:92;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29693;}s:9:"thumbnail";a:5:{s:4:"file";s:22:"BERKLEY@2x-150x112.png";s:5:"width";i:150;s:6:"height";i:112;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16258;}s:11:"admin-thumb";a:5:{s:4:"file";s:21:"BERKLEY@2x-100x31.png";s:5:"width";i:100;s:6:"height";i:31;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4733;}s:7:"350x230";a:5:{s:4:"file";s:22:"BERKLEY@2x-350x112.png";s:5:"width";i:350;s:6:"height";i:112;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:32173;}s:7:"278x278";a:5:{s:4:"file";s:22:"BERKLEY@2x-278x112.png";s:5:"width";i:278;s:6:"height";i:112;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:30263;}s:7:"200x200";a:5:{s:4:"file";s:22:"BERKLEY@2x-200x112.png";s:5:"width";i:200;s:6:"height";i:112;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:22157;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(345, 120, '_wp_attached_file', '2022/10/BSE.png'),
(346, 120, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:108;s:6:"height";i:41;s:4:"file";s:15:"2022/10/BSE.png";s:8:"filesize";i:5927;s:5:"sizes";a:1:{s:11:"admin-thumb";a:5:{s:4:"file";s:14:"BSE-100x38.png";s:5:"width";i:100;s:6:"height";i:38;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6615;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(347, 121, '_wp_attached_file', '2022/10/BSE@2x.png'),
(348, 121, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:216;s:6:"height";i:82;s:4:"file";s:18:"2022/10/BSE@2x.png";s:8:"filesize";i:15165;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:17:"BSE@2x-150x82.png";s:5:"width";i:150;s:6:"height";i:82;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:10549;}s:11:"admin-thumb";a:5:{s:4:"file";s:17:"BSE@2x-100x38.png";s:5:"width";i:100;s:6:"height";i:38;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:5740;}s:7:"200x200";a:5:{s:4:"file";s:17:"BSE@2x-200x82.png";s:5:"width";i:200;s:6:"height";i:82;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12436;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(349, 122, '_wp_attached_file', '2022/10/CHUBB.png'),
(350, 122, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:95;s:6:"height";i:107;s:4:"file";s:17:"2022/10/CHUBB.png";s:8:"filesize";i:13365;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(351, 123, '_wp_attached_file', '2022/10/CHUBB@2x.png'),
(352, 123, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:190;s:6:"height";i:214;s:4:"file";s:20:"2022/10/CHUBB@2x.png";s:8:"filesize";i:44527;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"CHUBB@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:25204;}s:11:"admin-thumb";a:5:{s:4:"file";s:20:"CHUBB@2x-100x113.png";s:5:"width";i:100;s:6:"height";i:113;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:15678;}s:7:"200x200";a:5:{s:4:"file";s:20:"CHUBB@2x-190x200.png";s:5:"width";i:190;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:33430;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(353, 124, '_wp_attached_file', '2022/10/f2be4fdccb71ff923ed513e031c7f3a4.png'),
(354, 124, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:350;s:6:"height";i:196;s:4:"file";s:44:"2022/10/f2be4fdccb71ff923ed513e031c7f3a4.png";s:8:"filesize";i:123948;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:44:"f2be4fdccb71ff923ed513e031c7f3a4-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:77973;}s:9:"thumbnail";a:5:{s:4:"file";s:44:"f2be4fdccb71ff923ed513e031c7f3a4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37815;}s:11:"admin-thumb";a:5:{s:4:"file";s:43:"f2be4fdccb71ff923ed513e031c7f3a4-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11430;}s:7:"278x278";a:5:{s:4:"file";s:44:"f2be4fdccb71ff923ed513e031c7f3a4-278x196.png";s:5:"width";i:278;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:88929;}s:7:"200x200";a:5:{s:4:"file";s:44:"f2be4fdccb71ff923ed513e031c7f3a4-200x196.png";s:5:"width";i:200;s:6:"height";i:196;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:66223;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(355, 125, '_wp_attached_file', '2022/10/f2be4fdccb71ff923ed513e031c7f3a4@2x.png'),
(356, 125, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:700;s:6:"height";i:392;s:4:"file";s:47:"2022/10/f2be4fdccb71ff923ed513e031c7f3a4@2x.png";s:8:"filesize";i:392016;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:47:"f2be4fdccb71ff923ed513e031c7f3a4@2x-300x168.png";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:77223;}s:9:"thumbnail";a:5:{s:4:"file";s:47:"f2be4fdccb71ff923ed513e031c7f3a4@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37302;}s:11:"admin-thumb";a:5:{s:4:"file";s:46:"f2be4fdccb71ff923ed513e031c7f3a4@2x-100x56.png";s:5:"width";i:100;s:6:"height";i:56;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11233;}s:7:"350x230";a:5:{s:4:"file";s:47:"f2be4fdccb71ff923ed513e031c7f3a4@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:115796;}s:7:"278x278";a:5:{s:4:"file";s:47:"f2be4fdccb71ff923ed513e031c7f3a4@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:110721;}s:7:"200x200";a:5:{s:4:"file";s:47:"f2be4fdccb71ff923ed513e031c7f3a4@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:61840;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(357, 126, '_wp_attached_file', '2022/10/Fundo-Equipe.png'),
(358, 126, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:1211;s:4:"file";s:24:"2022/10/Fundo-Equipe.png";s:8:"filesize";i:722911;s:5:"sizes";a:9:{s:6:"medium";a:5:{s:4:"file";s:24:"Fundo-Equipe-300x252.png";s:5:"width";i:300;s:6:"height";i:252;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:40512;}s:5:"large";a:5:{s:4:"file";s:25:"Fundo-Equipe-1024x861.png";s:5:"width";i:1024;s:6:"height";i:861;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:327536;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"Fundo-Equipe-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14530;}s:12:"medium_large";a:5:{s:4:"file";s:24:"Fundo-Equipe-768x646.png";s:5:"width";i:768;s:6:"height";i:646;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:194946;}s:11:"admin-thumb";a:5:{s:4:"file";s:23:"Fundo-Equipe-100x84.png";s:5:"width";i:100;s:6:"height";i:84;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6325;}s:7:"350x230";a:5:{s:4:"file";s:24:"Fundo-Equipe-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:42231;}s:8:"1600x768";a:5:{s:4:"file";s:25:"Fundo-Equipe-1440x768.png";s:5:"width";i:1440;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:327444;}s:7:"278x278";a:5:{s:4:"file";s:24:"Fundo-Equipe-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:41547;}s:7:"200x200";a:5:{s:4:"file";s:24:"Fundo-Equipe-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23650;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(359, 127, '_wp_attached_file', '2022/10/Fundo-Equipe@2x.png'),
(360, 127, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2880;s:6:"height";i:2422;s:4:"file";s:27:"2022/10/Fundo-Equipe@2x.png";s:8:"filesize";i:1531778;s:5:"sizes";a:11:{s:6:"medium";a:5:{s:4:"file";s:27:"Fundo-Equipe@2x-300x252.png";s:5:"width";i:300;s:6:"height";i:252;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:40559;}s:5:"large";a:5:{s:4:"file";s:28:"Fundo-Equipe@2x-1024x861.png";s:5:"width";i:1024;s:6:"height";i:861;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:328985;}s:9:"thumbnail";a:5:{s:4:"file";s:27:"Fundo-Equipe@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14609;}s:12:"medium_large";a:5:{s:4:"file";s:27:"Fundo-Equipe@2x-768x646.png";s:5:"width";i:768;s:6:"height";i:646;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:194432;}s:9:"1536x1536";a:5:{s:4:"file";s:29:"Fundo-Equipe@2x-1536x1292.png";s:5:"width";i:1536;s:6:"height";i:1292;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:631763;}s:9:"2048x2048";a:5:{s:4:"file";s:29:"Fundo-Equipe@2x-2048x1722.png";s:5:"width";i:2048;s:6:"height";i:1722;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1131122;}s:11:"admin-thumb";a:5:{s:4:"file";s:26:"Fundo-Equipe@2x-100x84.png";s:5:"width";i:100;s:6:"height";i:84;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6341;}s:7:"350x230";a:5:{s:4:"file";s:27:"Fundo-Equipe@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:42251;}s:8:"1600x768";a:5:{s:4:"file";s:28:"Fundo-Equipe@2x-1600x768.png";s:5:"width";i:1600;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:422435;}s:7:"278x278";a:5:{s:4:"file";s:27:"Fundo-Equipe@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:41646;}s:7:"200x200";a:5:{s:4:"file";s:27:"Fundo-Equipe@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:23762;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(361, 128, '_wp_attached_file', '2022/10/GBoex.png'),
(362, 128, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:199;s:6:"height";i:90;s:4:"file";s:17:"2022/10/GBoex.png";s:8:"filesize";i:25005;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:16:"GBoex-150x90.png";s:5:"width";i:150;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21595;}s:11:"admin-thumb";a:5:{s:4:"file";s:16:"GBoex-100x45.png";s:5:"width";i:100;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7506;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(363, 129, '_wp_attached_file', '2022/10/GBoex@2x.png'),
(364, 129, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:398;s:6:"height";i:180;s:4:"file";s:20:"2022/10/GBoex@2x.png";s:8:"filesize";i:83959;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:20:"GBoex@2x-300x136.png";s:5:"width";i:300;s:6:"height";i:136;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:55776;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"GBoex@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:35771;}s:11:"admin-thumb";a:5:{s:4:"file";s:19:"GBoex@2x-100x45.png";s:5:"width";i:100;s:6:"height";i:45;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7584;}s:7:"350x230";a:5:{s:4:"file";s:20:"GBoex@2x-350x180.png";s:5:"width";i:350;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:71201;}s:7:"278x278";a:5:{s:4:"file";s:20:"GBoex@2x-278x180.png";s:5:"width";i:278;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:66956;}s:7:"200x200";a:5:{s:4:"file";s:20:"GBoex@2x-200x180.png";s:5:"width";i:200;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:49943;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(365, 130, '_wp_attached_file', '2022/10/GolderCross.png'),
(366, 130, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:233;s:6:"height";i:91;s:4:"file";s:23:"2022/10/GolderCross.png";s:8:"filesize";i:9788;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:22:"GolderCross-150x91.png";s:5:"width";i:150;s:6:"height";i:91;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4823;}s:11:"admin-thumb";a:5:{s:4:"file";s:22:"GolderCross-100x39.png";s:5:"width";i:100;s:6:"height";i:39;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3385;}s:7:"200x200";a:5:{s:4:"file";s:22:"GolderCross-200x91.png";s:5:"width";i:200;s:6:"height";i:91;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6600;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(367, 131, '_wp_attached_file', '2022/10/GolderCross@2x.png'),
(368, 131, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:466;s:6:"height";i:182;s:4:"file";s:26:"2022/10/GolderCross@2x.png";s:8:"filesize";i:30672;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:26:"GolderCross@2x-300x117.png";s:5:"width";i:300;s:6:"height";i:117;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:20337;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"GolderCross@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12753;}s:11:"admin-thumb";a:5:{s:4:"file";s:25:"GolderCross@2x-100x39.png";s:5:"width";i:100;s:6:"height";i:39;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3168;}s:7:"350x230";a:5:{s:4:"file";s:26:"GolderCross@2x-350x182.png";s:5:"width";i:350;s:6:"height";i:182;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16113;}s:7:"278x278";a:5:{s:4:"file";s:26:"GolderCross@2x-278x182.png";s:5:"width";i:278;s:6:"height";i:182;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:13284;}s:7:"200x200";a:5:{s:4:"file";s:26:"GolderCross@2x-200x182.png";s:5:"width";i:200;s:6:"height";i:182;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9493;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(369, 132, '_wp_attached_file', '2022/10/HDI.png'),
(370, 132, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:138;s:6:"height";i:54;s:4:"file";s:15:"2022/10/HDI.png";s:8:"filesize";i:2133;s:5:"sizes";a:1:{s:11:"admin-thumb";a:5:{s:4:"file";s:14:"HDI-100x39.png";s:5:"width";i:100;s:6:"height";i:39;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3241;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(371, 133, '_wp_attached_file', '2022/10/HDI@2x.png'),
(372, 133, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:276;s:6:"height";i:108;s:4:"file";s:18:"2022/10/HDI@2x.png";s:8:"filesize";i:6585;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"HDI@2x-150x108.png";s:5:"width";i:150;s:6:"height";i:108;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3847;}s:11:"admin-thumb";a:5:{s:4:"file";s:17:"HDI@2x-100x39.png";s:5:"width";i:100;s:6:"height";i:39;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3101;}s:7:"200x200";a:5:{s:4:"file";s:18:"HDI@2x-200x108.png";s:5:"width";i:200;s:6:"height";i:108;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4329;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(373, 134, '_wp_attached_file', '2022/10/Imagem-Banner-01.png'),
(374, 134, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:680;s:4:"file";s:28:"2022/10/Imagem-Banner-01.png";s:8:"filesize";i:854882;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:28:"Imagem-Banner-01-300x142.png";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:50391;}s:5:"large";a:5:{s:4:"file";s:29:"Imagem-Banner-01-1024x484.png";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:480367;}s:9:"thumbnail";a:5:{s:4:"file";s:28:"Imagem-Banner-01-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28069;}s:12:"medium_large";a:5:{s:4:"file";s:28:"Imagem-Banner-01-768x363.png";s:5:"width";i:768;s:6:"height";i:363;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:280650;}s:11:"admin-thumb";a:5:{s:4:"file";s:27:"Imagem-Banner-01-100x47.png";s:5:"width";i:100;s:6:"height";i:47;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7130;}s:7:"350x230";a:5:{s:4:"file";s:28:"Imagem-Banner-01-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:89433;}s:7:"278x278";a:5:{s:4:"file";s:28:"Imagem-Banner-01-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:86570;}s:7:"200x200";a:5:{s:4:"file";s:28:"Imagem-Banner-01-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:47158;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(375, 135, '_wp_attached_file', '2022/10/Imagem-Banner-01@2x.png'),
(376, 135, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2880;s:6:"height";i:1360;s:4:"file";s:31:"2022/10/Imagem-Banner-01@2x.png";s:8:"filesize";i:2845313;s:5:"sizes";a:11:{s:6:"medium";a:5:{s:4:"file";s:31:"Imagem-Banner-01@2x-300x142.png";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:50272;}s:5:"large";a:5:{s:4:"file";s:32:"Imagem-Banner-01@2x-1024x484.png";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:478522;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"Imagem-Banner-01@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28088;}s:12:"medium_large";a:5:{s:4:"file";s:31:"Imagem-Banner-01@2x-768x363.png";s:5:"width";i:768;s:6:"height";i:363;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:275005;}s:9:"1536x1536";a:5:{s:4:"file";s:32:"Imagem-Banner-01@2x-1536x725.png";s:5:"width";i:1536;s:6:"height";i:725;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:955492;}s:9:"2048x2048";a:5:{s:4:"file";s:32:"Imagem-Banner-01@2x-2048x967.png";s:5:"width";i:2048;s:6:"height";i:967;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1616444;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"Imagem-Banner-01@2x-100x47.png";s:5:"width";i:100;s:6:"height";i:47;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7158;}s:7:"350x230";a:5:{s:4:"file";s:31:"Imagem-Banner-01@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:89051;}s:8:"1600x768";a:5:{s:4:"file";s:32:"Imagem-Banner-01@2x-1600x768.png";s:5:"width";i:1600;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1144686;}s:7:"278x278";a:5:{s:4:"file";s:31:"Imagem-Banner-01@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:85553;}s:7:"200x200";a:5:{s:4:"file";s:31:"Imagem-Banner-01@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:47028;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(377, 136, '_wp_attached_file', '2022/10/Imagem-Banner-02.png'),
(378, 136, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:680;s:4:"file";s:28:"2022/10/Imagem-Banner-02.png";s:8:"filesize";i:906831;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:28:"Imagem-Banner-02-300x142.png";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:56807;}s:5:"large";a:5:{s:4:"file";s:29:"Imagem-Banner-02-1024x484.png";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:451448;}s:9:"thumbnail";a:5:{s:4:"file";s:28:"Imagem-Banner-02-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:32627;}s:12:"medium_large";a:5:{s:4:"file";s:28:"Imagem-Banner-02-768x363.png";s:5:"width";i:768;s:6:"height";i:363;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:259816;}s:11:"admin-thumb";a:5:{s:4:"file";s:27:"Imagem-Banner-02-100x47.png";s:5:"width";i:100;s:6:"height";i:47;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7975;}s:7:"350x230";a:5:{s:4:"file";s:28:"Imagem-Banner-02-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:102977;}s:7:"278x278";a:5:{s:4:"file";s:28:"Imagem-Banner-02-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:99874;}s:7:"200x200";a:5:{s:4:"file";s:28:"Imagem-Banner-02-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:52775;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(379, 137, '_wp_attached_file', '2022/10/Imagem-Banner-02@2x.png'),
(380, 137, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2880;s:6:"height";i:1360;s:4:"file";s:31:"2022/10/Imagem-Banner-02@2x.png";s:8:"filesize";i:2913163;s:5:"sizes";a:11:{s:6:"medium";a:5:{s:4:"file";s:31:"Imagem-Banner-02@2x-300x142.png";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:55309;}s:5:"large";a:5:{s:4:"file";s:32:"Imagem-Banner-02@2x-1024x484.png";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:451783;}s:9:"thumbnail";a:5:{s:4:"file";s:31:"Imagem-Banner-02@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:31589;}s:12:"medium_large";a:5:{s:4:"file";s:31:"Imagem-Banner-02@2x-768x363.png";s:5:"width";i:768;s:6:"height";i:363;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:256068;}s:9:"1536x1536";a:5:{s:4:"file";s:32:"Imagem-Banner-02@2x-1536x725.png";s:5:"width";i:1536;s:6:"height";i:725;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:890427;}s:9:"2048x2048";a:5:{s:4:"file";s:32:"Imagem-Banner-02@2x-2048x967.png";s:5:"width";i:2048;s:6:"height";i:967;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1536851;}s:11:"admin-thumb";a:5:{s:4:"file";s:30:"Imagem-Banner-02@2x-100x47.png";s:5:"width";i:100;s:6:"height";i:47;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7946;}s:7:"350x230";a:5:{s:4:"file";s:31:"Imagem-Banner-02@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:101072;}s:8:"1600x768";a:5:{s:4:"file";s:32:"Imagem-Banner-02@2x-1600x768.png";s:5:"width";i:1600;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1261615;}s:7:"278x278";a:5:{s:4:"file";s:31:"Imagem-Banner-02@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:97536;}s:7:"200x200";a:5:{s:4:"file";s:31:"Imagem-Banner-02@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:51798;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(381, 138, '_wp_attached_file', '2022/10/JNS.png'),
(382, 138, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:61;s:6:"height";i:46;s:4:"file";s:15:"2022/10/JNS.png";s:8:"filesize";i:2978;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(383, 139, '_wp_attached_file', '2022/10/JNS@2x.png'),
(384, 139, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:121;s:6:"height";i:92;s:4:"file";s:18:"2022/10/JNS@2x.png";s:8:"filesize";i:9239;s:5:"sizes";a:1:{s:11:"admin-thumb";a:5:{s:4:"file";s:17:"JNS@2x-100x76.png";s:5:"width";i:100;s:6:"height";i:76;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8155;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(385, 140, '_wp_attached_file', '2022/10/Mapa.png'),
(386, 140, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:533;s:6:"height";i:374;s:4:"file";s:16:"2022/10/Mapa.png";s:8:"filesize";i:130819;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:16:"Mapa-300x211.png";s:5:"width";i:300;s:6:"height";i:211;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:73459;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"Mapa-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28109;}s:11:"admin-thumb";a:5:{s:4:"file";s:15:"Mapa-100x70.png";s:5:"width";i:100;s:6:"height";i:70;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:10062;}s:7:"350x230";a:5:{s:4:"file";s:16:"Mapa-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:92521;}s:7:"278x278";a:5:{s:4:"file";s:16:"Mapa-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:84359;}s:7:"200x200";a:5:{s:4:"file";s:16:"Mapa-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:47695;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(387, 141, '_wp_attached_file', '2022/10/Mapa@2x.png'),
(388, 141, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1066;s:6:"height";i:748;s:4:"file";s:19:"2022/10/Mapa@2x.png";s:8:"filesize";i:402312;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:19:"Mapa@2x-300x211.png";s:5:"width";i:300;s:6:"height";i:211;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:71578;}s:5:"large";a:5:{s:4:"file";s:20:"Mapa@2x-1024x719.png";s:5:"width";i:1024;s:6:"height";i:719;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:573599;}s:9:"thumbnail";a:5:{s:4:"file";s:19:"Mapa@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:27403;}s:12:"medium_large";a:5:{s:4:"file";s:19:"Mapa@2x-768x539.png";s:5:"width";i:768;s:6:"height";i:539;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:382967;}s:11:"admin-thumb";a:5:{s:4:"file";s:18:"Mapa@2x-100x70.png";s:5:"width";i:100;s:6:"height";i:70;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9946;}s:7:"350x230";a:5:{s:4:"file";s:19:"Mapa@2x-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:92246;}s:7:"278x278";a:5:{s:4:"file";s:19:"Mapa@2x-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:83735;}s:7:"200x200";a:5:{s:4:"file";s:19:"Mapa@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:45693;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(389, 142, '_wp_attached_file', '2022/10/Mitsui.png'),
(390, 142, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:162;s:6:"height";i:61;s:4:"file";s:18:"2022/10/Mitsui.png";s:8:"filesize";i:5285;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:17:"Mitsui-150x61.png";s:5:"width";i:150;s:6:"height";i:61;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4796;}s:11:"admin-thumb";a:5:{s:4:"file";s:17:"Mitsui-100x38.png";s:5:"width";i:100;s:6:"height";i:38;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3862;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(391, 143, '_wp_attached_file', '2022/10/Mitsui@2x.png'),
(392, 143, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:324;s:6:"height";i:122;s:4:"file";s:21:"2022/10/Mitsui@2x.png";s:8:"filesize";i:17218;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:21:"Mitsui@2x-300x113.png";s:5:"width";i:300;s:6:"height";i:113;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:21686;}s:9:"thumbnail";a:5:{s:4:"file";s:21:"Mitsui@2x-150x122.png";s:5:"width";i:150;s:6:"height";i:122;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6310;}s:11:"admin-thumb";a:5:{s:4:"file";s:20:"Mitsui@2x-100x38.png";s:5:"width";i:100;s:6:"height";i:38;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3711;}s:7:"278x278";a:5:{s:4:"file";s:21:"Mitsui@2x-278x122.png";s:5:"width";i:278;s:6:"height";i:122;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:14626;}s:7:"200x200";a:5:{s:4:"file";s:21:"Mitsui@2x-200x122.png";s:5:"width";i:200;s:6:"height";i:122;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:8730;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(393, 144, '_wp_attached_file', '2022/10/SABEMI.png'),
(394, 144, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:102;s:6:"height";i:107;s:4:"file";s:18:"2022/10/SABEMI.png";s:8:"filesize";i:9920;s:5:"sizes";a:1:{s:11:"admin-thumb";a:5:{s:4:"file";s:18:"SABEMI-100x105.png";s:5:"width";i:100;s:6:"height";i:105;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12365;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(395, 145, '_wp_attached_file', '2022/10/SABEMI@2x.png'),
(396, 145, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:204;s:6:"height";i:214;s:4:"file";s:21:"2022/10/SABEMI@2x.png";s:8:"filesize";i:31268;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:21:"SABEMI@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:22250;}s:11:"admin-thumb";a:5:{s:4:"file";s:21:"SABEMI@2x-100x105.png";s:5:"width";i:100;s:6:"height";i:105;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12450;}s:7:"200x200";a:5:{s:4:"file";s:21:"SABEMI@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37327;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(397, 146, '_wp_attached_file', '2022/10/SOMPO.png'),
(398, 146, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:105;s:6:"height";i:117;s:4:"file";s:17:"2022/10/SOMPO.png";s:8:"filesize";i:15859;s:5:"sizes";a:1:{s:11:"admin-thumb";a:5:{s:4:"file";s:17:"SOMPO-100x111.png";s:5:"width";i:100;s:6:"height";i:111;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16429;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(399, 147, '_wp_attached_file', '2022/10/SOMPO@2x.png'),
(400, 147, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:210;s:6:"height";i:234;s:4:"file";s:20:"2022/10/SOMPO@2x.png";s:8:"filesize";i:51050;s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:20:"SOMPO@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:26200;}s:11:"admin-thumb";a:5:{s:4:"file";s:20:"SOMPO@2x-100x111.png";s:5:"width";i:100;s:6:"height";i:111;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:16330;}s:7:"350x230";a:5:{s:4:"file";s:20:"SOMPO@2x-210x230.png";s:5:"width";i:210;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:42258;}s:7:"200x200";a:5:{s:4:"file";s:20:"SOMPO@2x-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:44394;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(401, 148, '_wp_attached_file', '2022/10/SulAmérica.png'),
(402, 148, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:164;s:6:"height";i:42;s:4:"file";s:24:"2022/10/SulAmérica.png";s:8:"filesize";i:7795;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:23:"SulAmérica-150x42.png";s:5:"width";i:150;s:6:"height";i:42;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:6135;}s:11:"admin-thumb";a:5:{s:4:"file";s:23:"SulAmérica-100x26.png";s:5:"width";i:100;s:6:"height";i:26;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4791;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(403, 149, '_wp_attached_file', '2022/10/SulAmérica@2x.png'),
(404, 149, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:328;s:6:"height";i:84;s:4:"file";s:27:"2022/10/SulAmérica@2x.png";s:8:"filesize";i:23460;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:26:"SulAmérica@2x-300x77.png";s:5:"width";i:300;s:6:"height";i:77;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:25574;}s:9:"thumbnail";a:5:{s:4:"file";s:26:"SulAmérica@2x-150x84.png";s:5:"width";i:150;s:6:"height";i:84;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9203;}s:11:"admin-thumb";a:5:{s:4:"file";s:26:"SulAmérica@2x-100x26.png";s:5:"width";i:100;s:6:"height";i:26;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4799;}s:7:"278x278";a:5:{s:4:"file";s:26:"SulAmérica@2x-278x84.png";s:5:"width";i:278;s:6:"height";i:84;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:15863;}s:7:"200x200";a:5:{s:4:"file";s:26:"SulAmérica@2x-200x84.png";s:5:"width";i:200;s:6:"height";i:84;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:11138;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(405, 150, '_wp_attached_file', '2022/10/ZURICH.png'),
(406, 150, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:129;s:6:"height";i:94;s:4:"file";s:18:"2022/10/ZURICH.png";s:8:"filesize";i:12831;s:5:"sizes";a:1:{s:11:"admin-thumb";a:5:{s:4:"file";s:17:"ZURICH-100x73.png";s:5:"width";i:100;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9819;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(407, 151, '_wp_attached_file', '2022/10/ZURICH@2x.png'),
(408, 151, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:258;s:6:"height";i:187;s:4:"file";s:21:"2022/10/ZURICH@2x.png";s:8:"filesize";i:41341;s:5:"sizes";a:3:{s:9:"thumbnail";a:5:{s:4:"file";s:21:"ZURICH@2x-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:26935;}s:11:"admin-thumb";a:5:{s:4:"file";s:20:"ZURICH@2x-100x72.png";s:5:"width";i:100;s:6:"height";i:72;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9709;}s:7:"200x200";a:5:{s:4:"file";s:21:"ZURICH@2x-200x187.png";s:5:"width";i:200;s:6:"height";i:187;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:28824;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(409, 152, '_edit_last', '1'),
(410, 152, '_thumbnail_id', '150'),
(411, 152, '_edit_lock', '1666790684:1'),
(412, 153, '_edit_last', '1'),
(413, 153, '_thumbnail_id', '146'),
(414, 153, '_edit_lock', '1666790680:1'),
(415, 154, '_edit_last', '1'),
(416, 154, '_thumbnail_id', '148'),
(417, 154, '_edit_lock', '1666790674:1'),
(418, 155, '_edit_last', '1'),
(419, 155, '_thumbnail_id', '144'),
(420, 155, '_edit_lock', '1666790667:1'),
(421, 156, '_edit_last', '1'),
(422, 156, '_thumbnail_id', '138'),
(423, 156, '_edit_lock', '1666790662:1'),
(424, 157, '_edit_last', '1'),
(425, 157, '_thumbnail_id', '142'),
(426, 157, '_edit_lock', '1666790657:1'),
(427, 158, '_edit_last', '1'),
(428, 158, '_thumbnail_id', '114'),
(429, 158, '_edit_lock', '1666790650:1'),
(430, 159, '_edit_last', '1'),
(431, 159, '_thumbnail_id', '128'),
(432, 159, '_edit_lock', '1666790645:1'),
(433, 160, '_edit_last', '1'),
(434, 160, '_thumbnail_id', '122'),
(435, 160, '_edit_lock', '1666790634:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(436, 161, '_edit_last', '1'),
(437, 161, '_thumbnail_id', '120'),
(438, 161, '_edit_lock', '1666790638:1'),
(439, 162, '_edit_last', '1'),
(440, 162, '_thumbnail_id', '118'),
(441, 162, '_edit_lock', '1666790548:1'),
(442, 163, '_edit_last', '1'),
(443, 163, '_thumbnail_id', '112'),
(444, 163, '_edit_lock', '1666790541:1'),
(445, 165, '_edit_last', '1'),
(446, 165, '_thumbnail_id', '116'),
(447, 165, '_edit_lock', '1667496172:1'),
(448, 89, '_thumbnail_id', '98'),
(449, 89, 'funcao', 'Sócio Fundador'),
(450, 89, '_funcao', 'field_63556db97d893'),
(451, 89, 'linkedin', 'https://www.linkedin.com/in/jo%C3%A3o-firmino-torelly-bastos-8b0a3359/'),
(452, 89, '_linkedin', 'field_63556de305c26'),
(453, 89, 'reverse', '0'),
(454, 89, '_reverse', 'field_6355712236b49'),
(455, 166, '_edit_last', '1'),
(456, 166, '_edit_lock', '1667557532:1'),
(457, 166, 'funcao', 'Sócio Gestor'),
(458, 166, '_funcao', 'field_63556db97d893'),
(459, 166, 'linkedin', 'https://www.linkedin.com/in/eduardo-rodrigues-silva/'),
(460, 166, '_linkedin', 'field_63556de305c26'),
(461, 166, 'reverse', '1'),
(462, 166, '_reverse', 'field_6355712236b49'),
(463, 167, '_edit_last', '1'),
(464, 167, '_edit_lock', '1666966970:1'),
(465, 167, '_thumbnail_id', '92'),
(466, 167, 'funcao', 'Sócio Gestor'),
(467, 167, '_funcao', 'field_63556db97d893'),
(468, 167, 'linkedin', 'https://www.linkedin.com/in/marcelo-barreto-leal-5665aa244/'),
(469, 167, '_linkedin', 'field_63556de305c26'),
(470, 167, 'reverse', '1'),
(471, 167, '_reverse', 'field_6355712236b49'),
(472, 168, '_edit_last', '1'),
(473, 168, '_edit_lock', '1668002144:1'),
(474, 168, '_thumbnail_id', '96'),
(475, 168, 'funcao', 'Sócia Gerente'),
(476, 168, '_funcao', 'field_63556db97d893'),
(477, 168, 'linkedin', 'https://www.linkedin.com/in/luana-scheid-dahinten-baa96871/'),
(478, 168, '_linkedin', 'field_63556de305c26'),
(479, 168, 'reverse', '0'),
(480, 168, '_reverse', 'field_6355712236b49'),
(481, 169, '_edit_last', '1'),
(482, 169, '_edit_lock', '1666967080:1'),
(483, 169, '_thumbnail_id', '94'),
(484, 169, 'funcao', 'Sócio Gerente'),
(485, 169, '_funcao', 'field_63556db97d893'),
(486, 169, 'linkedin', 'https://www.linkedin.com/in/vin%C3%ADcius-de-lima-pellin-28559b10a/'),
(487, 169, '_linkedin', 'field_63556de305c26'),
(488, 169, 'reverse', '0'),
(489, 169, '_reverse', 'field_6355712236b49'),
(490, 172, '_edit_last', '1'),
(491, 172, '_edit_lock', '1666626404:1'),
(492, 172, 'icone', '{"style":"solid","id":"file-invoice-dollar","label":"File Invoice with US Dollar","unicode":"f571"}'),
(493, 172, '_icone', 'field_635572181797d'),
(494, 173, '_edit_last', '1'),
(495, 173, '_edit_lock', '1666626450:1'),
(496, 173, 'icone', '{"style":"solid","id":"house","label":"House","unicode":"f015"}'),
(497, 173, '_icone', 'field_635572181797d'),
(498, 174, '_edit_last', '1'),
(499, 174, '_edit_lock', '1666626468:1'),
(500, 174, 'icone', '{"style":"solid","id":"cart-shopping","label":"Cart shopping","unicode":"f07a"}'),
(501, 174, '_icone', 'field_635572181797d'),
(502, 175, '_edit_last', '1'),
(503, 175, '_edit_lock', '1666626500:1'),
(504, 175, 'icone', '{"style":"solid","id":"scale-balanced","label":"Scale balanced","unicode":"f24e"}'),
(505, 175, '_icone', 'field_635572181797d'),
(506, 176, '_edit_last', '1'),
(507, 176, '_edit_lock', '1666626542:1'),
(508, 176, 'icone', '{"style":"regular","id":"handshake","label":"Handshake","unicode":"f2b5"}'),
(509, 176, '_icone', 'field_635572181797d'),
(510, 177, '_edit_last', '1'),
(511, 177, '_edit_lock', '1666626582:1'),
(512, 177, 'icone', '{"style":"solid","id":"magnifying-glass-dollar","label":"Magnifying glass dollar","unicode":"f688"}'),
(513, 177, '_icone', 'field_635572181797d'),
(514, 178, '_edit_last', '1'),
(515, 178, '_edit_lock', '1667573920:1'),
(516, 178, 'icone', '{"style":"solid","id":"shield","label":"shield","unicode":"f132"}'),
(517, 178, '_icone', 'field_635572181797d'),
(518, 180, '_edit_last', '1'),
(519, 180, '_edit_lock', '1666626845:1'),
(520, 180, 'icone', '{"style":"solid","id":"users","label":"Users","unicode":"f0c0"}'),
(521, 180, '_icone', 'field_635572181797d'),
(522, 181, '_edit_last', '1'),
(523, 181, '_edit_lock', '1666626872:1'),
(524, 181, 'icone', '{"style":"solid","id":"users-viewfinder","label":"Users Viewfinder","unicode":"e595"}'),
(525, 181, '_icone', 'field_635572181797d'),
(526, 182, '_edit_last', '1'),
(527, 182, '_edit_lock', '1666627152:1'),
(528, 182, 'icone', '{"style":"solid","id":"bars","label":"Bars","unicode":"f0c9"}'),
(529, 182, '_icone', 'field_635572181797d'),
(530, 183, '_edit_last', '1'),
(531, 183, '_edit_lock', '1666627263:1'),
(532, 183, 'icone', '{"style":"solid","id":"gear","label":"Gear","unicode":"f013"}'),
(533, 183, '_icone', 'field_635572181797d'),
(534, 184, '_edit_last', '1'),
(535, 184, '_edit_lock', '1666627337:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(536, 184, 'icone', '{"style":"solid","id":"people-arrows","label":"People arrows left right","unicode":"e068"}'),
(537, 184, '_icone', 'field_635572181797d'),
(538, 80, '_config_errors', 'a:1:{s:11:"mail.sender";a:1:{i:0;a:2:{s:4:"code";i:103;s:4:"args";a:3:{s:7:"message";s:0:"";s:6:"params";a:0:{}s:4:"link";s:70:"https://contactform7.com/configuration-errors/email-not-in-site-domain";}}}}'),
(539, 186, '_wp_attached_file', '2022/10/1657376859522-5.png'),
(540, 186, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:278;s:6:"height";i:278;s:4:"file";s:27:"2022/10/1657376859522-5.png";s:8:"filesize";i:146346;s:5:"sizes";a:4:{s:9:"thumbnail";a:5:{s:4:"file";s:27:"1657376859522-5-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:37412;}s:11:"admin-thumb";a:5:{s:4:"file";s:27:"1657376859522-5-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18067;}s:7:"350x230";a:5:{s:4:"file";s:27:"1657376859522-5-278x230.png";s:5:"width";i:278;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:101317;}s:7:"200x200";a:5:{s:4:"file";s:27:"1657376859522-5-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:63363;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(541, 166, '_thumbnail_id', '186'),
(542, 169, '_wp_old_date', '2022-10-24'),
(543, 168, '_wp_old_date', '2022-10-26'),
(544, 167, '_wp_old_date', '2022-10-27'),
(545, 166, '_wp_old_date', '2022-10-28'),
(546, 89, '_wp_old_date', '2022-10-29'),
(547, 69, '_wp_old_date', '2022-10-30'),
(548, 188, '_wp_attached_file', '2022/10/View_TRB_005_22_Banner-Site_001d.png'),
(549, 188, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:680;s:4:"file";s:44:"2022/10/View_TRB_005_22_Banner-Site_001d.png";s:8:"filesize";i:1036274;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:44:"View_TRB_005_22_Banner-Site_001d-300x142.png";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:50531;}s:5:"large";a:5:{s:4:"file";s:45:"View_TRB_005_22_Banner-Site_001d-1024x484.png";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:482485;}s:9:"thumbnail";a:5:{s:4:"file";s:44:"View_TRB_005_22_Banner-Site_001d-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:30683;}s:12:"medium_large";a:5:{s:4:"file";s:44:"View_TRB_005_22_Banner-Site_001d-768x363.png";s:5:"width";i:768;s:6:"height";i:363;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:287068;}s:11:"admin-thumb";a:5:{s:4:"file";s:43:"View_TRB_005_22_Banner-Site_001d-100x47.png";s:5:"width";i:100;s:6:"height";i:47;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:7480;}s:7:"350x230";a:5:{s:4:"file";s:44:"View_TRB_005_22_Banner-Site_001d-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:93033;}s:7:"278x278";a:5:{s:4:"file";s:44:"View_TRB_005_22_Banner-Site_001d-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:93520;}s:7:"200x200";a:5:{s:4:"file";s:44:"View_TRB_005_22_Banner-Site_001d-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:51509;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(550, 193, '_menu_item_type', 'custom'),
(551, 193, '_menu_item_menu_item_parent', '0'),
(552, 193, '_menu_item_object_id', '193'),
(553, 193, '_menu_item_object', 'custom'),
(554, 193, '_menu_item_target', ''),
(555, 193, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(556, 193, '_menu_item_xfn', ''),
(557, 193, '_menu_item_url', '#areas'),
(559, 37, '_wp_old_date', '2022-10-22'),
(560, 38, '_wp_old_date', '2022-10-22'),
(561, 194, '_menu_item_type', 'custom'),
(562, 194, '_menu_item_menu_item_parent', '0'),
(563, 194, '_menu_item_object_id', '194'),
(564, 194, '_menu_item_object', 'custom'),
(565, 194, '_menu_item_target', ''),
(566, 194, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(567, 194, '_menu_item_xfn', ''),
(568, 194, '_menu_item_url', 'https://localhost/torellybastos.com.br/blog/'),
(570, 195, '_menu_item_type', 'custom'),
(571, 195, '_menu_item_menu_item_parent', '0'),
(572, 195, '_menu_item_object_id', '195'),
(573, 195, '_menu_item_object', 'custom'),
(574, 195, '_menu_item_target', ''),
(575, 195, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(576, 195, '_menu_item_xfn', ''),
(577, 195, '_menu_item_url', '#contato'),
(579, 196, '_menu_item_type', 'custom'),
(580, 196, '_menu_item_menu_item_parent', '0'),
(581, 196, '_menu_item_object_id', '196'),
(582, 196, '_menu_item_object', 'custom'),
(583, 196, '_menu_item_target', ''),
(584, 196, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(585, 196, '_menu_item_xfn', ''),
(586, 196, '_menu_item_url', 'https://localhost/torellybastos.com.br/politica-de-privacidade'),
(590, 199, '_edit_last', '1'),
(591, 199, '_edit_lock', '1666793239:1'),
(592, 199, 'icone', '{"style":"brands","id":"telegram","label":"Telegram","unicode":"f2c6"}'),
(593, 199, '_icone', 'field_63593e0f9c219'),
(594, 199, '_wp_trash_meta_status', 'publish'),
(595, 199, '_wp_trash_meta_time', '1666793387'),
(596, 199, '_wp_desired_post_slug', 'teste'),
(603, 200, '_menu_item_type', 'custom'),
(604, 200, '_menu_item_menu_item_parent', '0'),
(605, 200, '_menu_item_object_id', '200'),
(606, 200, '_menu_item_object', 'custom'),
(607, 200, '_menu_item_target', ''),
(608, 200, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(609, 200, '_menu_item_xfn', ''),
(610, 200, '_menu_item_url', 'https://localhost/torellybastos.com.br/blog/'),
(612, 201, '_menu_item_type', 'custom'),
(613, 201, '_menu_item_menu_item_parent', '0'),
(614, 201, '_menu_item_object_id', '201'),
(615, 201, '_menu_item_object', 'custom'),
(616, 201, '_menu_item_target', ''),
(617, 201, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(618, 201, '_menu_item_xfn', ''),
(619, 201, '_menu_item_url', '#areas'),
(621, 202, '_menu_item_type', 'custom'),
(622, 202, '_menu_item_menu_item_parent', '0'),
(623, 202, '_menu_item_object_id', '202'),
(624, 202, '_menu_item_object', 'custom'),
(625, 202, '_menu_item_target', ''),
(626, 202, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(627, 202, '_menu_item_xfn', ''),
(628, 202, '_menu_item_url', '#contato'),
(630, 32, '_wp_old_date', '2022-10-22'),
(631, 33, '_wp_old_date', '2022-10-22'),
(632, 203, '_wp_attached_file', '2022/10/View_TRB_005_22_Banner-Site_001c-1.png'),
(633, 203, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1440;s:6:"height";i:680;s:4:"file";s:46:"2022/10/View_TRB_005_22_Banner-Site_001c-1.png";s:8:"filesize";i:463590;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:46:"View_TRB_005_22_Banner-Site_001c-1-300x142.png";s:5:"width";i:300;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29507;}s:5:"large";a:5:{s:4:"file";s:47:"View_TRB_005_22_Banner-Site_001c-1-1024x484.png";s:5:"width";i:1024;s:6:"height";i:484;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:230074;}s:9:"thumbnail";a:5:{s:4:"file";s:46:"View_TRB_005_22_Banner-Site_001c-1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19306;}s:12:"medium_large";a:5:{s:4:"file";s:46:"View_TRB_005_22_Banner-Site_001c-1-768x363.png";s:5:"width";i:768;s:6:"height";i:363;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:138736;}s:11:"admin-thumb";a:5:{s:4:"file";s:45:"View_TRB_005_22_Banner-Site_001c-1-100x47.png";s:5:"width";i:100;s:6:"height";i:47;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:5775;}s:7:"350x230";a:5:{s:4:"file";s:46:"View_TRB_005_22_Banner-Site_001c-1-350x230.png";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:52757;}s:7:"278x278";a:5:{s:4:"file";s:46:"View_TRB_005_22_Banner-Site_001c-1-278x278.png";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:51478;}s:7:"200x200";a:5:{s:4:"file";s:46:"View_TRB_005_22_Banner-Site_001c-1-200x200.png";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:29859;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(634, 206, '_edit_lock', '1667496078:1'),
(635, 207, '_edit_lock', '1667496326:1'),
(636, 207, '_edit_last', '1'),
(637, 209, '_wp_attached_file', '2022/11/AHA_2015_003_0766.jpg'),
(638, 209, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2248;s:6:"height";i:1500;s:4:"file";s:29:"2022/11/AHA_2015_003_0766.jpg";s:8:"filesize";i:364562;s:5:"sizes";a:11:{s:6:"medium";a:5:{s:4:"file";s:29:"AHA_2015_003_0766-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:13639;}s:5:"large";a:5:{s:4:"file";s:30:"AHA_2015_003_0766-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:77353;}s:9:"thumbnail";a:5:{s:4:"file";s:29:"AHA_2015_003_0766-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6719;}s:12:"medium_large";a:5:{s:4:"file";s:29:"AHA_2015_003_0766-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:51337;}s:9:"1536x1536";a:5:{s:4:"file";s:31:"AHA_2015_003_0766-1536x1025.jpg";s:5:"width";i:1536;s:6:"height";i:1025;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:137463;}s:9:"2048x2048";a:5:{s:4:"file";s:31:"AHA_2015_003_0766-2048x1367.jpg";s:5:"width";i:2048;s:6:"height";i:1367;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:210374;}s:11:"admin-thumb";a:5:{s:4:"file";s:28:"AHA_2015_003_0766-100x67.jpg";s:5:"width";i:100;s:6:"height";i:67;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3094;}s:7:"350x230";a:5:{s:4:"file";s:29:"AHA_2015_003_0766-350x230.jpg";s:5:"width";i:350;s:6:"height";i:230;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16838;}s:8:"1600x768";a:5:{s:4:"file";s:30:"AHA_2015_003_0766-1600x768.jpg";s:5:"width";i:1600;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:104722;}s:7:"278x278";a:5:{s:4:"file";s:29:"AHA_2015_003_0766-278x278.jpg";s:5:"width";i:278;s:6:"height";i:278;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16145;}s:7:"200x200";a:5:{s:4:"file";s:29:"AHA_2015_003_0766-200x200.jpg";s:5:"width";i:200;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10057;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"4";s:6:"credit";s:22:"Andre Hilgert [MIAGUI]";s:6:"camera";s:11:"NIKON D800E";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1428757422";s:9:"copyright";s:6:"MIAGUI";s:12:"focal_length";s:2:"24";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:6:"0.0125";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(639, 210, 'galeria_sobre', 'a:3:{i:0;s:2:"49";i:1;s:2:"82";i:2;s:3:"209";}'),
(640, 210, '_galeria_sobre', 'field_635565c9881a9'),
(641, 210, 'texto_1', 'A TORELLY BASTOS ADVOGADOS ASSOCIADOS tem uma trajetória de mais de vinte anos de dedicação no atendimento de clientes empresariais. Com atuação nacional, está sediada na cidade de Porto Alegre/RS, com excelente localização geográfica, situando-se em ponto estratégico e nobre da Capital, onde são concentrados os atos gerenciais e realizada a coordenação de todas as operações. Escritório sempre atualizado, com profissionais especializados, oportunizando excelentes resultados nas frentes de atuação.'),
(642, 210, '_texto_1', 'field_635565d4881aa'),
(643, 210, 'texto_2', 'Com recursos tecnológicos de ponta, possui uma estrutura organizacional e estratégica que permite estar preparado para o atendimento das mais diversas necessidades dos seus clientes, administrativas e judiciais. Referência no seguimento do Direito do Seguro, Previdência Privada, Responsabilidade Civil, Relações de Consumo, também atua no Direito Bancário, Trabalhista, Tributário, Recuperação Judicial e Ambiental.'),
(644, 210, '_texto_2', 'field_635565df881ab'),
(645, 210, 'icone_missao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(646, 210, '_icone_missao', 'field_635569ad53b6d'),
(647, 210, 'titulo_missao', 'MISSÃO'),
(648, 210, '_titulo_missao', 'field_6355698153b6b'),
(649, 210, 'texto_missao', 'Nosso maior compromisso é construir soluções inovadoras para nossos parceiros de negócios'),
(650, 210, '_texto_missao', 'field_6355699a53b6c') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(651, 210, 'icone_visao', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(652, 210, '_icone_visao', 'field_635569c053b6e'),
(653, 210, 'titulo_visao', 'Visão'),
(654, 210, '_titulo_visao', 'field_635569c953b6f'),
(655, 210, 'texto_visao', 'Ser o escritório mais qualificado do país no segmento e o preferido dos seus públicos de interesse.'),
(656, 210, '_texto_visao', 'field_635569d253b70'),
(657, 210, 'icone_valores', '{"style":"solid","id":"bullseye","label":"Bullseye","unicode":"f140"}'),
(658, 210, '_icone_valores', 'field_63556aaf53b71'),
(659, 210, 'titulo_valores', 'Valores'),
(660, 210, '_titulo_valores', 'field_63556b4d53b72'),
(661, 210, 'texto_valores', 'Atuação primada pela idoneidade, transparência, colaboração e prontidão para mudanças.'),
(662, 210, '_texto_valores', 'field_63556b6153b73'),
(663, 211, '_edit_lock', '1668021453:1') ;

#
# Fim do conteúdo da tabela `wp_postmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_posts` existente
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Estrutura da tabela `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-10-18 13:00:16', '2022-10-18 16:00:16', '<!-- wp:paragraph -->\n<p>Boas-vindas ao WordPress. Esse é o seu primeiro post. Edite-o ou exclua-o, e então comece a escrever!</p>\n<!-- /wp:paragraph -->', 'Olá, mundo!', '', 'publish', 'open', 'open', '', 'ola-mundo', '', '', '2022-10-23 10:40:13', '2022-10-23 13:40:13', '', 0, 'http://localhost/torellybastos.com.br/?p=1', 0, 'post', '', 1),
(2, 1, '2022-10-18 13:00:16', '2022-10-18 16:00:16', '<!-- wp:paragraph -->\n<p>Esta é uma página de exemplo. É diferente de um post no blog porque ela permanecerá em um lugar e aparecerá na navegação do seu site na maioria dos temas. Muitas pessoas começam com uma página que as apresenta a possíveis visitantes do site. Ela pode dizer algo assim:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Olá! Eu sou um mensageiro de bicicleta durante o dia, ator aspirante à noite, e este é o meu site. Eu moro em São Paulo, tenho um grande cachorro chamado Rex e gosto de tomar caipirinha (e banhos de chuva).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...ou alguma coisa assim:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>A Companhia de Miniaturas XYZ foi fundada em 1971, e desde então tem fornecido miniaturas de qualidade ao público. Localizada na cidade de Itu, a XYZ emprega mais de 2.000 pessoas e faz coisas grandiosas para a comunidade da cidade.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Como um novo usuário do WordPress, você deveria ir ao <a href="http://localhost/torellybastos.com.br/wp-admin/">painel</a> para excluir essa página e criar novas páginas para o seu conteúdo. Divirta-se!</p>\n<!-- /wp:paragraph -->', 'Página de exemplo', '', 'publish', 'closed', 'open', '', 'pagina-exemplo', '', '', '2022-10-18 13:00:16', '2022-10-18 16:00:16', '', 0, 'http://localhost/torellybastos.com.br/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-10-18 13:00:16', '2022-10-18 16:00:16', '<!-- wp:heading --><h2>Quem somos</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>O endereço do nosso site é: http://localhost/torellybastos.com.br.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comentários</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Quando os visitantes deixam comentários no site, coletamos os dados mostrados no formulário de comentários, além do endereço de IP e de dados do navegador do visitante, para auxiliar na detecção de spam.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Uma sequência anonimizada de caracteres criada a partir do seu e-mail (também chamada de hash) poderá ser enviada para o Gravatar para verificar se você usa o serviço. A política de privacidade do Gravatar está disponível aqui: https://automattic.com/privacy/. Depois da aprovação do seu comentário, a foto do seu perfil fica visível publicamente junto de seu comentário.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Mídia</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você envia imagens para o site, evite enviar as que contenham dados de localização incorporados (EXIF GPS). Visitantes podem baixar estas imagens do site e extrair delas seus dados de localização.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Ao deixar um comentário no site, você poderá optar por salvar seu nome, e-mail e site nos cookies. Isso visa seu conforto, assim você não precisará preencher seus  dados novamente quando fizer outro comentário. Estes cookies duram um ano.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se você tem uma conta e acessa este site, um cookie temporário será criado para determinar se seu navegador aceita cookies. Ele não contém nenhum dado pessoal e será descartado quando você fechar seu navegador.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Quando você acessa sua conta no site, também criamos vários cookies para salvar os dados da sua conta e suas escolhas de exibição de tela. Cookies de login são mantidos por dois dias e cookies de opções de tela por um ano. Se você selecionar &quot;Lembrar-me&quot;, seu acesso será mantido por duas semanas. Se você se desconectar da sua conta, os cookies de login serão removidos.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Se você editar ou publicar um artigo, um cookie adicional será salvo no seu navegador. Este cookie não inclui nenhum dado pessoal e simplesmente indica o ID do post referente ao artigo que você acabou de editar. Ele expira depois de 1 dia.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Mídia incorporada de outros sites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Artigos neste site podem incluir conteúdo incorporado como, por exemplo, vídeos, imagens, artigos, etc. Conteúdos incorporados de outros sites se comportam exatamente da mesma forma como se o visitante estivesse visitando o outro site.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Estes sites podem coletar dados sobre você, usar cookies, incorporar rastreamento adicional de terceiros e monitorar sua interação com este conteúdo incorporado, incluindo sua interação com o conteúdo incorporado se você tem uma conta e está conectado com o site.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Com quem compartilhamos seus dados</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você solicitar uma redefinição de senha, seu endereço de IP será incluído no e-mail de redefinição de senha.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Por quanto tempo mantemos os seus dados</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você deixar um comentário, o comentário e os seus metadados são conservados indefinidamente. Fazemos isso para que seja possível reconhecer e aprovar automaticamente qualquer comentário posterior ao invés de retê-lo para moderação.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Para usuários que se registram no nosso site (se houver), também guardamos as informações pessoais que fornecem no seu perfil de usuário. Todos os usuários podem ver, editar ou excluir suas informações pessoais a qualquer momento (só não é possível alterar o seu username). Os administradores de sites também podem ver e editar estas informações.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Quais os seus direitos sobre seus dados</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Se você tiver uma conta neste site ou se tiver deixado comentários, pode solicitar um arquivo exportado dos dados pessoais que mantemos sobre você, inclusive quaisquer dados que nos tenha fornecido. Também pode solicitar que removamos qualquer dado pessoal que mantemos sobre você. Isto não inclui nenhuns dados que somos obrigados a manter para propósitos administrativos, legais ou de segurança.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Para onde seus dados são enviados</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texto sugerido: </strong>Comentários de visitantes podem ser marcados por um serviço automático de detecção de spam.</p><!-- /wp:paragraph -->', 'Política de privacidade', '', 'draft', 'closed', 'open', '', 'politica-de-privacidade', '', '', '2022-10-18 13:00:16', '2022-10-18 16:00:16', '', 0, 'http://localhost/torellybastos.com.br/?page_id=3', 0, 'page', '', 0),
(6, 1, '2022-10-18 13:09:31', '2022-10-18 16:09:31', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-11-09 10:55:24', '2022-11-09 13:55:24', '', 0, 'http://localhost/torellybastos.com.br/?page_id=6', 0, 'page', '', 0),
(7, 1, '2022-10-18 13:09:37', '2022-10-18 16:09:37', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2022-10-18 14:12:43', '2022-10-18 17:12:43', '', 0, 'http://localhost/torellybastos.com.br/?page_id=7', 0, 'page', '', 0),
(8, 1, '2022-10-18 13:08:51', '2022-10-18 16:08:51', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-s3', '', '', '2022-10-18 13:08:51', '2022-10-18 16:08:51', '', 0, 'http://localhost/torellybastos.com.br/wp-global-styles-s3/', 0, 'wp_global_styles', '', 0),
(9, 1, '2022-10-18 13:09:31', '2022-10-18 16:09:31', '', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-10-18 13:09:31', '2022-10-18 16:09:31', '', 6, 'http://localhost/torellybastos.com.br/?p=9', 0, 'revision', '', 0),
(10, 1, '2022-10-18 13:09:37', '2022-10-18 16:09:37', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-10-18 13:09:37', '2022-10-18 16:09:37', '', 7, 'http://localhost/torellybastos.com.br/?p=10', 0, 'revision', '', 0),
(11, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:14:"opcoes-do-Tema";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Opções do site', 'opcoes-do-site', 'publish', 'closed', 'closed', '', 'group_634ed2781dce7', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 0, 'http://localhost/torellybastos.com.br/?post_type=acf-field-group&#038;p=11', 0, 'acf-field-group', '', 0),
(12, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Redes Sociais', 'redes_sociais', 'publish', 'closed', 'closed', '', 'field_634ed2e324ad1', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 11, 'http://localhost/torellybastos.com.br/?post_type=acf-field&#038;p=12', 2, 'acf-field', '', 0),
(13, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Redes Sociais', 'redes_sociais', 'publish', 'closed', 'closed', '', 'field_634ed2f124ad2', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 11, 'http://localhost/torellybastos.com.br/?post_type=acf-field&#038;p=13', 3, 'acf-field', '', 0),
(14, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:15:{s:4:"type";s:12:"font-awesome";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"icon_sets";a:3:{i:0;s:5:"solid";i:1;s:7:"regular";i:2;s:6:"brands";}s:15:"custom_icon_set";s:0:"";s:13:"default_label";s:0:"";s:13:"default_value";s:0:"";s:11:"save_format";s:7:"element";s:10:"allow_null";i:0;s:12:"show_preview";i:1;s:10:"enqueue_fa";i:0;s:15:"fa_live_preview";s:0:"";s:7:"choices";a:0:{}}', 'Icone', 'icone', 'publish', 'closed', 'closed', '', 'field_634ed30424ad3', '', '', '2022-10-18 13:24:36', '2022-10-18 16:24:36', '', 13, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=14', 0, 'acf-field', '', 0),
(15, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";}', 'Url', 'url', 'publish', 'closed', 'closed', '', 'field_634ed30c24ad4', '', '', '2022-10-18 13:24:36', '2022-10-18 16:24:36', '', 13, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=15', 1, 'acf-field', '', 0),
(16, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Informações empresa', 'informacoes_empresa', 'publish', 'closed', 'closed', '', 'field_634ed31d24ad5', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 11, 'http://localhost/torellybastos.com.br/?post_type=acf-field&#038;p=16', 4, 'acf-field', '', 0),
(17, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Informações empresa', 'informacoes_empresa', 'publish', 'closed', 'closed', '', 'field_634ed32324ad6', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 11, 'http://localhost/torellybastos.com.br/?post_type=acf-field&#038;p=17', 5, 'acf-field', '', 0),
(18, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:15:{s:4:"type";s:12:"font-awesome";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"icon_sets";a:3:{i:0;s:5:"solid";i:1;s:7:"regular";i:2;s:6:"brands";}s:15:"custom_icon_set";s:0:"";s:13:"default_label";s:0:"";s:13:"default_value";s:0:"";s:11:"save_format";s:7:"element";s:10:"allow_null";i:0;s:12:"show_preview";i:1;s:10:"enqueue_fa";i:0;s:15:"fa_live_preview";s:0:"";s:7:"choices";a:0:{}}', 'Icone', 'icone', 'publish', 'closed', 'closed', '', 'field_634ed33124ad7', '', '', '2022-10-18 13:24:36', '2022-10-18 16:24:36', '', 17, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=18', 0, 'acf-field', '', 0),
(19, 1, '2022-10-18 13:24:36', '2022-10-18 16:24:36', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";}', 'Url', 'url', 'publish', 'closed', 'closed', '', 'field_634ed33b24ad8', '', '', '2022-10-18 13:24:36', '2022-10-18 16:24:36', '', 17, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=19', 1, 'acf-field', '', 0),
(20, 1, '2022-10-18 13:41:05', '2022-10-18 16:41:05', '{"contato_fone":{"value":" 51 3092.7700","type":"option","user_id":1,"date_modified_gmt":"2022-10-18 16:41:05"}}', '', '', 'trash', 'closed', 'closed', '', 'b913c016-be15-4e4f-b0c1-ba42a6d901fd', '', '', '2022-10-18 13:41:05', '2022-10-18 16:41:05', '', 0, 'http://localhost/torellybastos.com.br/b913c016-be15-4e4f-b0c1-ba42a6d901fd/', 0, 'customize_changeset', '', 0),
(21, 1, '2022-10-18 13:41:52', '2022-10-18 16:41:52', '{"contato_email":{"value":"torellybastos@torellybastos.com.br","type":"option","user_id":1,"date_modified_gmt":"2022-10-18 16:41:52"}}', '', '', 'trash', 'closed', 'closed', '', 'fbc374b5-c17e-4c80-bcdc-ddfa0d60998a', '', '', '2022-10-18 13:41:52', '2022-10-18 16:41:52', '', 0, 'http://localhost/torellybastos.com.br/fbc374b5-c17e-4c80-bcdc-ddfa0d60998a/', 0, 'customize_changeset', '', 0),
(27, 1, '2022-10-18 14:12:24', '2022-10-18 17:12:24', '', 'imagem-banner-blog', '', 'inherit', 'open', 'closed', '', 'imagem-banner-blog', '', '', '2022-10-18 14:12:24', '2022-10-18 17:12:24', '', 7, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/imagem-banner-blog.png', 0, 'attachment', 'image/png', 0),
(28, 1, '2022-10-18 14:12:35', '2022-10-18 17:12:35', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-10-18 14:12:35', '2022-10-18 17:12:35', '', 7, 'http://localhost/torellybastos.com.br/?p=28', 0, 'revision', '', 0),
(29, 1, '2022-10-18 14:12:43', '2022-10-18 17:12:43', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2022-10-18 14:12:43', '2022-10-18 17:12:43', '', 7, 'http://localhost/torellybastos.com.br/?p=29', 0, 'revision', '', 0),
(31, 1, '2022-10-22 09:35:39', '2022-10-22 12:35:39', '{"s3::nav_menu_locations[menu-desktop]":{"value":-4784066832979235000,"type":"theme_mod","user_id":1,"date_modified_gmt":"2022-10-22 12:35:39"},"nav_menu[-4784066832979235000]":{"value":{"name":"Menu Princial","description":"","parent":0,"auto_add":false},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-10-22 12:35:39"},"nav_menu_item[-1976291865585526800]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":1,"type":"custom","title":"Home","url":"#banner","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Home","nav_menu_term_id":-4784066832979235000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-10-22 12:35:39"},"nav_menu_item[-1656137455741374500]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":2,"type":"custom","title":"Sobre","url":"#sobre","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Sobre","nav_menu_term_id":-4784066832979235000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-10-22 12:35:39"}}', '', '', 'trash', 'closed', 'closed', '', 'd0eeecfb-4aa4-4475-ba5e-de7e3a791c5b', '', '', '2022-10-22 09:35:39', '2022-10-22 12:35:39', '', 0, 'http://localhost/torellybastos.com.br/d0eeecfb-4aa4-4475-ba5e-de7e3a791c5b/', 0, 'customize_changeset', '', 0),
(32, 1, '2022-10-26 11:44:16', '2022-10-22 12:35:39', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2022-10-26 11:44:16', '2022-10-26 14:44:16', '', 0, 'http://localhost/torellybastos.com.br/home/', 1, 'nav_menu_item', '', 0),
(33, 1, '2022-10-26 11:44:16', '2022-10-22 12:35:39', '', 'Quem Somos', '', 'publish', 'closed', 'closed', '', 'sobre', '', '', '2022-10-26 11:44:16', '2022-10-26 14:44:16', '', 0, 'http://localhost/torellybastos.com.br/sobre/', 2, 'nav_menu_item', '', 0),
(34, 1, '2022-10-22 09:36:46', '2022-10-22 12:36:46', '{"nav_menu_item[-311752578814296060]":{"value":{"object_id":7,"object":"page","menu_item_parent":0,"position":3,"type":"post_type","title":"Blog","url":"http:\\/\\/localhost\\/torellybastos.com.br\\/blog\\/","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Blog","nav_menu_term_id":3,"_invalid":false,"type_label":"P\\u00e1gina de posts"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-10-22 12:36:46"}}', '', '', 'trash', 'closed', 'closed', '', 'cc79331e-4861-4ca6-9a5f-8cc112160dcb', '', '', '2022-10-22 09:36:46', '2022-10-22 12:36:46', '', 0, 'http://localhost/torellybastos.com.br/cc79331e-4861-4ca6-9a5f-8cc112160dcb/', 0, 'customize_changeset', '', 0),
(36, 1, '2022-10-22 09:39:17', '2022-10-22 12:39:17', '{"s3::nav_menu_locations[menu-footer-1]":{"value":-4301564868433527000,"type":"theme_mod","user_id":1,"date_modified_gmt":"2022-10-22 12:39:17"},"nav_menu[-4301564868433527000]":{"value":{"name":"Menu Footer 1","description":"","parent":0,"auto_add":false},"type":"nav_menu","user_id":1,"date_modified_gmt":"2022-10-22 12:39:17"},"nav_menu_item[-3958395560039727000]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":1,"type":"custom","title":"Home","url":"#banner","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Home","nav_menu_term_id":-4301564868433527000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-10-22 12:39:17"},"nav_menu_item[-8035843994355562000]":{"value":{"object_id":0,"object":"custom","menu_item_parent":0,"position":2,"type":"custom","title":"Sobre","url":"#sobre","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Sobre","nav_menu_term_id":-4301564868433527000,"_invalid":false,"type_label":"Link personalizado"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-10-22 12:39:17"}}', '', '', 'trash', 'closed', 'closed', '', 'e11c0376-c590-458c-b5b0-f4c1d63c0d45', '', '', '2022-10-22 09:39:17', '2022-10-22 12:39:17', '', 0, 'http://localhost/torellybastos.com.br/e11c0376-c590-458c-b5b0-f4c1d63c0d45/', 0, 'customize_changeset', '', 0),
(37, 1, '2022-10-26 10:57:41', '2022-10-22 12:39:17', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home-2', '', '', '2022-10-26 10:57:41', '2022-10-26 13:57:41', '', 0, 'http://localhost/torellybastos.com.br/home-2/', 1, 'nav_menu_item', '', 0),
(38, 1, '2022-10-26 10:57:41', '2022-10-22 12:39:17', '', 'Quem Somos', '', 'publish', 'closed', 'closed', '', 'sobre-2', '', '', '2022-10-26 10:57:41', '2022-10-26 13:57:41', '', 0, 'http://localhost/torellybastos.com.br/sobre-2/', 2, 'nav_menu_item', '', 0),
(39, 1, '2022-10-22 10:04:39', '2022-10-22 13:04:39', '<!-- wp:paragraph -->\n<p>Teste</p>\n<!-- /wp:paragraph -->', 'Teste', '', 'publish', 'open', 'open', '', 'teste', '', '', '2022-10-22 10:04:39', '2022-10-22 13:04:39', '', 0, 'http://localhost/torellybastos.com.br/?p=39', 0, 'post', '', 0),
(40, 1, '2022-10-22 10:04:26', '2022-10-22 13:04:26', '', 'banner', '', 'inherit', 'open', 'closed', '', 'banner', '', '', '2022-10-22 10:04:26', '2022-10-22 13:04:26', '', 39, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/banner.png', 0, 'attachment', 'image/png', 0),
(41, 1, '2022-10-22 10:04:39', '2022-10-22 13:04:39', '<!-- wp:paragraph -->\n<p>Teste</p>\n<!-- /wp:paragraph -->', 'Teste', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2022-10-22 10:04:39', '2022-10-22 13:04:39', '', 39, 'http://localhost/torellybastos.com.br/?p=41', 0, 'revision', '', 0),
(42, 1, '2022-10-23 10:40:13', '2022-10-23 13:40:13', '<!-- wp:paragraph -->\n<p>Boas-vindas ao WordPress. Esse é o seu primeiro post. Edite-o ou exclua-o, e então comece a escrever!</p>\n<!-- /wp:paragraph -->', 'Olá, mundo!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-10-23 10:40:13', '2022-10-23 13:40:13', '', 1, 'http://localhost/torellybastos.com.br/?p=42', 0, 'revision', '', 0),
(43, 1, '2022-10-23 12:57:44', '2022-10-23 15:57:44', 'Há 25 anos\r\natendendo <b>clientes</b>\r\n<b>empresariais</b>', '01', '', 'publish', 'closed', 'closed', '', '01', '', '', '2022-10-26 10:28:35', '2022-10-26 13:28:35', '', 0, 'http://localhost/torellybastos.com.br/?post_type=banners&#038;p=43', 0, 'banners', '', 0),
(44, 1, '2022-10-23 13:04:11', '2022-10-23 16:04:11', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"template-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Home', 'home', 'publish', 'closed', 'closed', '', 'group_635565b5b7bd2', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 0, 'http://localhost/torellybastos.com.br/?post_type=acf-field-group&#038;p=44', 0, 'acf-field-group', '', 0),
(45, 1, '2022-10-23 13:04:11', '2022-10-23 16:04:11', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Sobre', 'sobre', 'publish', 'closed', 'closed', '', 'field_635565c3881a8', '', '', '2022-10-23 13:04:11', '2022-10-23 16:04:11', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=45', 0, 'acf-field', '', 0),
(46, 1, '2022-10-23 13:04:11', '2022-10-23 16:04:11', 'a:18:{s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:6:"medium";s:6:"insert";s:6:"append";s:7:"library";s:3:"all";s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Galeria', 'galeria_sobre', 'publish', 'closed', 'closed', '', 'field_635565c9881a9', '', '', '2022-10-23 13:04:11', '2022-10-23 16:04:11', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=46', 1, 'acf-field', '', 0),
(47, 1, '2022-10-23 13:04:11', '2022-10-23 16:04:11', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Texto 1', 'texto_1', 'publish', 'closed', 'closed', '', 'field_635565d4881aa', '', '', '2022-10-23 13:04:11', '2022-10-23 16:04:11', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=47', 2, 'acf-field', '', 0),
(48, 1, '2022-10-23 13:04:11', '2022-10-23 16:04:11', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Texto 2', 'texto_2', 'publish', 'closed', 'closed', '', 'field_635565df881ab', '', '', '2022-10-23 13:04:11', '2022-10-23 16:04:11', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=48', 3, 'acf-field', '', 0),
(49, 1, '2022-10-23 13:09:02', '2022-10-23 16:09:02', '', 'galeria', '', 'inherit', 'open', 'closed', '', 'galeria', '', '', '2022-10-23 13:09:13', '2022-10-23 16:09:13', '', 6, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/galeria.png', 0, 'attachment', 'image/png', 0),
(51, 1, '2022-10-23 13:09:38', '2022-10-23 16:09:38', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-10-23 13:09:38', '2022-10-23 16:09:38', '', 6, 'http://localhost/torellybastos.com.br/?p=51', 0, 'revision', '', 0),
(52, 1, '2022-10-23 13:09:40', '2022-10-23 16:09:40', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-10-23 13:09:40', '2022-10-23 16:09:40', '', 6, 'http://localhost/torellybastos.com.br/?p=52', 0, 'revision', '', 0),
(53, 1, '2022-10-23 13:13:01', '2022-10-23 16:13:01', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-10-23 13:13:01', '2022-10-23 16:13:01', '', 6, 'http://localhost/torellybastos.com.br/?p=53', 0, 'revision', '', 0),
(54, 1, '2022-10-23 13:13:38', '2022-10-23 16:13:38', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-10-23 13:13:38', '2022-10-23 16:13:38', '', 6, 'http://localhost/torellybastos.com.br/?p=54', 0, 'revision', '', 0),
(55, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Missão, Visão e Valores', 'missao_visao_e_valores', 'publish', 'closed', 'closed', '', 'field_6355697353b6a', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=55', 4, 'acf-field', '', 0),
(56, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:15:{s:4:"type";s:12:"font-awesome";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"icon_sets";a:3:{i:0;s:5:"solid";i:1;s:7:"regular";i:2;s:6:"brands";}s:15:"custom_icon_set";s:0:"";s:13:"default_label";s:0:"";s:13:"default_value";s:0:"";s:11:"save_format";s:7:"element";s:10:"allow_null";i:0;s:12:"show_preview";i:1;s:10:"enqueue_fa";i:0;s:15:"fa_live_preview";s:0:"";s:7:"choices";a:0:{}}', 'Ícone', 'icone_missao', 'publish', 'closed', 'closed', '', 'field_635569ad53b6d', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=56', 5, 'acf-field', '', 0),
(57, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'titulo_missao', 'publish', 'closed', 'closed', '', 'field_6355698153b6b', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=57', 6, 'acf-field', '', 0),
(58, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Texto', 'texto_missao', 'publish', 'closed', 'closed', '', 'field_6355699a53b6c', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=58', 7, 'acf-field', '', 0),
(59, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:15:{s:4:"type";s:12:"font-awesome";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"icon_sets";a:3:{i:0;s:5:"solid";i:1;s:7:"regular";i:2;s:6:"brands";}s:15:"custom_icon_set";s:0:"";s:13:"default_label";s:0:"";s:13:"default_value";s:0:"";s:11:"save_format";s:7:"element";s:10:"allow_null";i:0;s:12:"show_preview";i:1;s:10:"enqueue_fa";i:0;s:15:"fa_live_preview";s:0:"";s:7:"choices";a:0:{}}', 'Ícone', 'icone_visao', 'publish', 'closed', 'closed', '', 'field_635569c053b6e', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=59', 8, 'acf-field', '', 0),
(60, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'titulo_visao', 'publish', 'closed', 'closed', '', 'field_635569c953b6f', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=60', 9, 'acf-field', '', 0),
(61, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Texto', 'texto_visao', 'publish', 'closed', 'closed', '', 'field_635569d253b70', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=61', 10, 'acf-field', '', 0),
(62, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:15:{s:4:"type";s:12:"font-awesome";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"icon_sets";a:3:{i:0;s:5:"solid";i:1;s:7:"regular";i:2;s:6:"brands";}s:15:"custom_icon_set";s:0:"";s:13:"default_label";s:0:"";s:13:"default_value";s:0:"";s:11:"save_format";s:7:"element";s:10:"allow_null";i:0;s:12:"show_preview";i:1;s:10:"enqueue_fa";i:0;s:15:"fa_live_preview";s:0:"";s:7:"choices";a:0:{}}', 'Ícone', 'icone_valores', 'publish', 'closed', 'closed', '', 'field_63556aaf53b71', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=62', 11, 'acf-field', '', 0),
(63, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Título', 'titulo_valores', 'publish', 'closed', 'closed', '', 'field_63556b4d53b72', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=63', 12, 'acf-field', '', 0),
(64, 1, '2022-10-23 13:28:43', '2022-10-23 16:28:43', 'a:10:{s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Texto', 'texto_valores', 'publish', 'closed', 'closed', '', 'field_63556b6153b73', '', '', '2022-10-23 13:28:43', '2022-10-23 16:28:43', '', 44, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=64', 13, 'acf-field', '', 0),
(65, 1, '2022-10-23 13:33:00', '2022-10-23 16:33:00', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-10-23 13:33:00', '2022-10-23 16:33:00', '', 6, 'http://localhost/torellybastos.com.br/?p=65', 0, 'revision', '', 0),
(66, 1, '2022-10-23 13:37:24', '2022-10-23 16:37:24', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:6:"equipe";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Equipe', 'equipe', 'publish', 'closed', 'closed', '', 'group_63556dad289f4', '', '', '2022-10-23 13:52:14', '2022-10-23 16:52:14', '', 0, 'http://localhost/torellybastos.com.br/?post_type=acf-field-group&#038;p=66', 0, 'acf-field-group', '', 0),
(67, 1, '2022-10-23 13:37:24', '2022-10-23 16:37:24', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Função', 'funcao', 'publish', 'closed', 'closed', '', 'field_63556db97d893', '', '', '2022-10-23 13:37:24', '2022-10-23 16:37:24', '', 66, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=67', 0, 'acf-field', '', 0),
(68, 1, '2022-10-23 13:38:07', '2022-10-23 16:38:07', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Linkedin', 'linkedin', 'publish', 'closed', 'closed', '', 'field_63556de305c26', '', '', '2022-10-23 13:38:07', '2022-10-23 16:38:07', '', 66, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=68', 1, 'acf-field', '', 0),
(69, 1, '2022-10-25 18:44:27', '2022-10-25 21:44:27', 'Graduado pela PUC/RS – Pós-Graduação em Direito Civil e Comercial – Especialização em Processo Civil – Curso de Extensão pela UNISINOS sobre Gestão Estratégica de Escritórios de Advocacia e Departamentos Jurídico. Membro fundador da Comissão Especial de Seguros e Previdência Complementar da OAB/RS. Membro da AIDA Brasil - Associação Internacional de Direito de Seguros. Sócio-Diretor e fundador da TORELLY BASTOS ADVOGADOS ASSOCIADOS, possuindo larga experiência jurídica e forense em Direito Civil e Processo Civil, com especial atuação e dedicação na defesa de Cias. Seguradoras e entidades de Previdência Privada.', 'Pedro Torelly Bastos', '', 'publish', 'closed', 'closed', '', 'pedro-torelly-bastos', '', '', '2022-10-28 11:23:57', '2022-10-28 14:23:57', '', 0, 'http://localhost/torellybastos.com.br/?post_type=equipe&#038;p=69', 0, 'equipe', '', 0),
(70, 1, '2022-10-23 13:43:57', '2022-10-23 16:43:57', '', 'equipe', '', 'inherit', 'open', 'closed', '', 'equipe', '', '', '2022-10-23 13:43:57', '2022-10-23 16:43:57', '', 69, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/equipe.png', 0, 'attachment', 'image/png', 0),
(71, 1, '2022-10-23 13:52:00', '2022-10-23 16:52:00', 'a:10:{s:4:"type";s:10:"true_false";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"message";s:0:"";s:13:"default_value";i:0;s:2:"ui";i:0;s:10:"ui_on_text";s:0:"";s:11:"ui_off_text";s:0:"";}', 'Reverse', 'reverse', 'publish', 'closed', 'closed', '', 'field_6355712236b49', '', '', '2022-10-23 13:52:00', '2022-10-23 16:52:00', '', 66, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=71', 2, 'acf-field', '', 0),
(72, 1, '2022-10-23 13:56:01', '2022-10-23 16:56:01', 'a:8:{s:8:"location";a:2:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:6:"gestao";}}i:1;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"areas";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Gestão', 'gestao', 'publish', 'closed', 'closed', '', 'group_63557212752f0', '', '', '2022-10-26 11:11:55', '2022-10-26 14:11:55', '', 0, 'http://localhost/torellybastos.com.br/?post_type=acf-field-group&#038;p=72', 0, 'acf-field-group', '', 0),
(73, 1, '2022-10-23 13:56:01', '2022-10-23 16:56:01', 'a:13:{s:4:"type";s:12:"font-awesome";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:10:"enqueue_fa";i:0;s:10:"allow_null";i:0;s:12:"show_preview";i:1;s:11:"save_format";s:7:"element";s:13:"default_value";s:0:"";s:13:"default_label";s:0:"";s:15:"fa_live_preview";s:0:"";s:7:"choices";a:0:{}}', 'Ícone', 'icone', 'publish', 'closed', 'closed', '', 'field_635572181797d', '', '', '2022-10-23 13:56:01', '2022-10-23 16:56:01', '', 72, 'http://localhost/torellybastos.com.br/?post_type=acf-field&p=73', 0, 'acf-field', '', 0),
(74, 1, '2022-10-23 13:58:13', '2022-10-23 16:58:13', '', 'PRODUTOS INOVADORES', '', 'publish', 'closed', 'closed', '', 'teste', '', '', '2022-10-24 12:55:48', '2022-10-24 15:55:48', '', 0, 'http://localhost/torellybastos.com.br/?post_type=gestao&#038;p=74', 0, 'gestao', '', 0),
(75, 1, '2022-10-23 13:58:51', '2022-10-23 16:58:51', '', 'AMBIENTAL', '', 'publish', 'closed', 'closed', '', 'teste-do-teste', '', '', '2022-10-24 12:48:41', '2022-10-24 15:48:41', '', 0, 'http://localhost/torellybastos.com.br/?post_type=areas&#038;p=75', 0, 'areas', '', 0),
(76, 1, '2022-10-23 14:07:18', '2022-10-23 17:07:18', '', 'HDI', '', 'draft', 'closed', 'closed', '', 'hdi', '', '', '2022-10-26 10:24:49', '2022-10-26 13:24:49', '', 0, 'http://localhost/torellybastos.com.br/?post_type=clientes&#038;p=76', 0, 'clientes', '', 0),
(77, 1, '2022-10-23 14:07:03', '2022-10-23 17:07:03', '', 'hdi-seguros-logo-14FA67393D-seeklogo.com_', '', 'inherit', 'open', 'closed', '', 'hdi-seguros-logo-14fa67393d-seeklogo-com_', '', '', '2022-10-23 14:07:03', '2022-10-23 17:07:03', '', 76, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/hdi-seguros-logo-14FA67393D-seeklogo.com_.jpg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2022-10-23 14:09:21', '2022-10-23 17:09:21', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Contato', 'contato', 'publish', 'closed', 'closed', '', 'field_6355752b1808b', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 11, 'http://localhost/torellybastos.com.br/?post_type=acf-field&#038;p=78', 6, 'acf-field', '', 0),
(79, 1, '2022-10-23 14:09:21', '2022-10-23 17:09:21', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Formulário', 'formulario', 'publish', 'closed', 'closed', '', 'field_635575381808c', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 11, 'http://localhost/torellybastos.com.br/?post_type=acf-field&#038;p=79', 7, 'acf-field', '', 0),
(80, 1, '2022-10-23 14:10:32', '2022-10-23 17:10:32', '<div class="mt-5">\r\n<div class="row mb-4">\r\n<div class="col-md-6">\r\n<div class="form-group mb-4 mb-md-0">\r\n[text* your-name class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary class:py-2 placeholder "Nome"]\r\n</div>\r\n</div>\r\n<div class="col-md-6">\r\n<div class="form-group">\r\n[email* your-email class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary class:py-2 placeholder "E-mail"]\r\n</div>\r\n</div>\r\n</div>\r\n<div class="row mb-4">\r\n<div class="col-md-6">\r\n<div class="form-group mb-4 mb-md-0">\r\n[tel* your-phone class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary class:py-2 placeholder "Telefone"]\r\n</div>\r\n</div>\r\n<div class="col-md-6">\r\n<div class="form-group">\r\n[text* your-subject class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary class:py-2 placeholder "Assunto"]\r\n</div>\r\n</div>\r\n</div>\r\n<div class="form-group mb-4">\r\n[textarea* your-message class:form-control class:border-0 class:rounded-0 class:font-14 class:text-primary placeholder "Mensagem"]\r\n</div>\r\n<!--\r\nREVISAR XD TEM CAMPOS DE CHCKBOX PARA RECEBER E-MAILS E ACEITE DE TERMOS\r\n-->\r\n<div>\r\n[submit class:btn class:btn-primary class:px-5 class:text-white class:rounded-0 "Enviar"]\r\n</div>\r\n</div>\n1\n[_site_title] "[your-subject]"\n[_site_title] <suporte@s3digital.com.br>\n[_site_admin_email]\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [your-email]\n\n\n\n\n[_site_title] "[your-subject]"\n[_site_title] <suporte@s3digital.com.br>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on [_site_title] ([_site_url])\nReply-To: [_site_admin_email]\n\n\n\nObrigado pela sua mensagem. Já foi enviada.\nOcorreu um erro ao tentar enviar sua mensagem. Por favor, tente novamente mais tarde.\nUm ou mais campos têm um erro. Por favor verifique e tente novamente.\nOcorreu um erro ao tentar enviar sua mensagem. Por favor, tente novamente mais tarde.\nVocê deve aceitar os termos e condições antes de enviar sua mensagem.\nO campo é obrigatório.\nO campo é muito longo.\nO campo é muito curto.\nOcorreu um erro desconhecido ao carregar o arquivo.\nVocê não tem permissão para fazer upload de arquivos deste tipo.\nO arquivo é muito grande.\nOcorreu um erro ao carregar o arquivo.\nO formato de data está incorreto.\nO formato de data está incorreto. A data é anterior à mais antiga permitida.\nA data é posterior à última permitida.\nO formato do número é inválido.\nO número é menor que o mínimo permitido.\nO número é maior que o máximo permitido.\nA resposta do quiz está incorreta.\nO endereço de e-mail inserido é inválido.\nO URL é inválido.\nO número de telefone é inválido.', 'Contato', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2022-10-24 13:14:06', '2022-10-24 16:14:06', '', 0, 'http://localhost/torellybastos.com.br/?post_type=wpcf7_contact_form&#038;p=80', 0, 'wpcf7_contact_form', '', 0),
(81, 1, '2022-10-24 11:21:06', '2022-10-24 14:21:06', '', 'AHD_2021_0274_0016', '', 'inherit', 'open', 'closed', '', 'ahd_2021_0274_0016', '', '', '2022-10-24 11:21:09', '2022-10-24 14:21:09', '', 6, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHD_2021_0274_0016.png', 0, 'attachment', 'image/png', 0),
(82, 1, '2022-10-24 11:21:49', '2022-10-24 14:21:49', '', 'AHA_2015_003_0020', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0020', '', '', '2022-10-24 11:22:06', '2022-10-24 14:22:06', '', 6, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020.png', 0, 'attachment', 'image/png', 0),
(83, 1, '2022-10-24 11:22:08', '2022-10-24 14:22:08', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-10-24 11:22:08', '2022-10-24 14:22:08', '', 6, 'https://localhost/torellybastos.com.br/?p=83', 0, 'revision', '', 0),
(84, 1, '2022-10-24 11:37:34', '2022-10-24 14:37:34', 'Gestão\r\nJurídica de\r\n<b>Alta Perfomance</b>', '02', '', 'publish', 'closed', 'closed', '', '02', '', '', '2022-10-28 11:18:07', '2022-10-28 14:18:07', '', 0, 'https://localhost/torellybastos.com.br/?post_type=banners&#038;p=84', 0, 'banners', '', 0),
(86, 1, '2022-10-24 11:36:54', '2022-10-24 14:36:54', '', 'Imagem-Banner_02', '', 'inherit', 'open', 'closed', '', 'imagem-banner_02', '', '', '2022-10-24 11:36:54', '2022-10-24 14:36:54', '', 84, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Imagem-Banner_02.png', 0, 'attachment', 'image/png', 0),
(88, 1, '2022-10-24 11:39:11', '2022-10-24 14:39:11', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-10-24 11:39:11', '2022-10-24 14:39:11', '', 6, 'https://localhost/torellybastos.com.br/?p=88', 0, 'revision', '', 0),
(89, 1, '2022-10-25 17:53:18', '2022-10-25 20:53:18', 'Advogado militante na área de seguros e previdência complementar, foi Assessor Jurídico de MBM Seguro de Pessoas entre 2005 e 2007 e seu Gerente Jurídico entre 2008 e 2012. Bacharel em Direito e Especialista em Direito, Mercado e Economia pela Pontifícia Universidade Católica do RS – PUCRS; Pós-graduado, lato sensu, em Gestão de Departamentos Jurídicos pela Universidade do Vale do Rio dos Sinos – UNISINOS; Mestre em Direito da Empresa e dos Negócios pela Universidade do Vale do Rio dos Sinos – UNISINOS com a realização de disciplinas na Washington University in Saint Louis - USA; Especialista en Derecho de Seguros por la Universidad de Salamanca – España; Membro da Seção Brasileira da Association Internationale de Droit des Assurances – AIDA, Presidente del Grupo de Trabajo de Automotores del Comité Ibero-Latinoamericano – CILA/AIDA; Membro Fundador da Comissão Especial de Seguros e Previdência Complementar da OAB/RS, tendo sido seu Presidente entre os anos de 2014 e 2018; Painelista e debatedor em eventos sobre o tema, bem como Professor Titular na UniRitter - Laureate International Universities e convidado em cursos de especialização em diversas instituições de ensino superior, entre elas a UNISINOS, CESUSC e PUCRS.', 'João Firmino Torelly Bastos', '', 'publish', 'closed', 'closed', '', 'joao-firmino-torelly-bastos', '', '', '2022-10-28 11:24:33', '2022-10-28 14:24:33', '', 0, 'https://localhost/torellybastos.com.br/?post_type=equipe&#038;p=89', 0, 'equipe', '', 0),
(90, 1, '2022-10-24 11:44:39', '2022-10-24 14:44:39', '', '1657376859522-1', '', 'inherit', 'open', 'closed', '', '1657376859522-1', '', '', '2022-10-24 11:44:39', '2022-10-24 14:44:39', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-1.png', 0, 'attachment', 'image/png', 0),
(91, 1, '2022-10-24 11:44:40', '2022-10-24 14:44:40', '', '1657376859522-1@2x', '', 'inherit', 'open', 'closed', '', '1657376859522-12x', '', '', '2022-10-24 11:44:40', '2022-10-24 14:44:40', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-1@2x.png', 0, 'attachment', 'image/png', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(92, 1, '2022-10-24 11:44:41', '2022-10-24 14:44:41', '', '1657376859522-2', '', 'inherit', 'open', 'closed', '', '1657376859522-2', '', '', '2022-10-24 11:44:41', '2022-10-24 14:44:41', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-2.png', 0, 'attachment', 'image/png', 0),
(93, 1, '2022-10-24 11:44:42', '2022-10-24 14:44:42', '', '1657376859522-2@2x', '', 'inherit', 'open', 'closed', '', '1657376859522-22x', '', '', '2022-10-24 11:44:42', '2022-10-24 14:44:42', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-2@2x.png', 0, 'attachment', 'image/png', 0),
(94, 1, '2022-10-24 11:44:43', '2022-10-24 14:44:43', '', '1657376859522-3', '', 'inherit', 'open', 'closed', '', '1657376859522-3', '', '', '2022-10-24 11:44:43', '2022-10-24 14:44:43', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-3.png', 0, 'attachment', 'image/png', 0),
(95, 1, '2022-10-24 11:44:44', '2022-10-24 14:44:44', '', '1657376859522-3@2x', '', 'inherit', 'open', 'closed', '', '1657376859522-32x', '', '', '2022-10-24 11:44:44', '2022-10-24 14:44:44', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-3@2x.png', 0, 'attachment', 'image/png', 0),
(96, 1, '2022-10-24 11:44:45', '2022-10-24 14:44:45', '', '1657376859522-4', '', 'inherit', 'open', 'closed', '', '1657376859522-4', '', '', '2022-10-24 11:44:45', '2022-10-24 14:44:45', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-4.png', 0, 'attachment', 'image/png', 0),
(97, 1, '2022-10-24 11:44:46', '2022-10-24 14:44:46', '', '1657376859522-4@2x', '', 'inherit', 'open', 'closed', '', '1657376859522-42x', '', '', '2022-10-24 11:44:46', '2022-10-24 14:44:46', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-4@2x.png', 0, 'attachment', 'image/png', 0),
(98, 1, '2022-10-24 11:44:47', '2022-10-24 14:44:47', '', '1657376859522', '', 'inherit', 'open', 'closed', '', '1657376859522', '', '', '2022-10-24 11:44:47', '2022-10-24 14:44:47', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522.png', 0, 'attachment', 'image/png', 0),
(99, 1, '2022-10-24 11:44:47', '2022-10-24 14:44:47', '', '1657376859522@2x', '', 'inherit', 'open', 'closed', '', '16573768595222x', '', '', '2022-10-24 11:44:47', '2022-10-24 14:44:47', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522@2x.png', 0, 'attachment', 'image/png', 0),
(100, 1, '2022-10-24 11:44:49', '2022-10-24 14:44:49', '', 'AdobeStock_399303485', '', 'inherit', 'open', 'closed', '', 'adobestock_399303485', '', '', '2022-10-24 11:44:49', '2022-10-24 14:44:49', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AdobeStock_399303485.png', 0, 'attachment', 'image/png', 0),
(101, 1, '2022-10-24 11:44:51', '2022-10-24 14:44:51', '', 'AdobeStock_399303485@2x', '', 'inherit', 'open', 'closed', '', 'adobestock_3993034852x', '', '', '2022-10-24 11:44:51', '2022-10-24 14:44:51', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AdobeStock_399303485@2x.png', 0, 'attachment', 'image/png', 0),
(102, 1, '2022-10-24 11:44:55', '2022-10-24 14:44:55', '', 'AHA_2015_003_0020-1', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0020-1', '', '', '2022-10-24 11:44:55', '2022-10-24 14:44:55', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020-1.png', 0, 'attachment', 'image/png', 0),
(103, 1, '2022-10-24 11:44:56', '2022-10-24 14:44:56', '', 'AHA_2015_003_0020-1@2x', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0020-12x', '', '', '2022-10-24 11:44:56', '2022-10-24 14:44:56', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020-1@2x.png', 0, 'attachment', 'image/png', 0),
(104, 1, '2022-10-24 11:44:57', '2022-10-24 14:44:57', '', 'AHA_2015_003_0020-2', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0020-2', '', '', '2022-10-24 11:44:57', '2022-10-24 14:44:57', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020-2.png', 0, 'attachment', 'image/png', 0),
(105, 1, '2022-10-24 11:44:58', '2022-10-24 14:44:58', '', 'AHA_2015_003_0020-2@2x', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0020-22x', '', '', '2022-10-24 11:44:58', '2022-10-24 14:44:58', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020-2@2x.png', 0, 'attachment', 'image/png', 0),
(106, 1, '2022-10-24 11:44:59', '2022-10-24 14:44:59', '', 'AHA_2015_003_0020-3', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0020-3', '', '', '2022-10-24 11:44:59', '2022-10-24 14:44:59', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020-3.png', 0, 'attachment', 'image/png', 0),
(107, 1, '2022-10-24 11:45:00', '2022-10-24 14:45:00', '', 'AHA_2015_003_0020-3@2x', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0020-32x', '', '', '2022-10-24 11:45:00', '2022-10-24 14:45:00', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020-3@2x.png', 0, 'attachment', 'image/png', 0),
(108, 1, '2022-10-24 11:45:01', '2022-10-24 14:45:01', '', 'AHA_2015_003_0020', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0020-4', '', '', '2022-10-24 11:45:01', '2022-10-24 14:45:01', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020-4.png', 0, 'attachment', 'image/png', 0),
(109, 1, '2022-10-24 11:45:02', '2022-10-24 14:45:02', '', 'AHA_2015_003_0020@2x', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_00202x', '', '', '2022-10-24 11:45:02', '2022-10-24 14:45:02', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHA_2015_003_0020@2x.png', 0, 'attachment', 'image/png', 0),
(110, 1, '2022-10-24 11:45:03', '2022-10-24 14:45:03', '', 'AHD_2021_0274_0016', '', 'inherit', 'open', 'closed', '', 'ahd_2021_0274_0016-2', '', '', '2022-10-24 11:45:03', '2022-10-24 14:45:03', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHD_2021_0274_0016-1.png', 0, 'attachment', 'image/png', 0),
(111, 1, '2022-10-24 11:45:04', '2022-10-24 14:45:04', '', 'AHD_2021_0274_0016@2x', '', 'inherit', 'open', 'closed', '', 'ahd_2021_0274_00162x', '', '', '2022-10-24 11:45:04', '2022-10-24 14:45:04', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/AHD_2021_0274_0016@2x.png', 0, 'attachment', 'image/png', 0),
(112, 1, '2022-10-24 11:45:05', '2022-10-24 14:45:05', '', 'Akad-Seguros', '', 'inherit', 'open', 'closed', '', 'akad-seguros', '', '', '2022-10-24 11:45:05', '2022-10-24 14:45:05', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Akad-Seguros.png', 0, 'attachment', 'image/png', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(113, 1, '2022-10-24 11:45:05', '2022-10-24 14:45:05', '', 'Akad-Seguros@2x', '', 'inherit', 'open', 'closed', '', 'akad-seguros2x', '', '', '2022-10-24 11:45:05', '2022-10-24 14:45:05', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Akad-Seguros@2x.png', 0, 'attachment', 'image/png', 0),
(114, 1, '2022-10-24 11:45:06', '2022-10-24 14:45:06', '', 'ALFA SEGURADORA', '', 'inherit', 'open', 'closed', '', 'alfa-seguradora', '', '', '2022-10-24 11:45:06', '2022-10-24 14:45:06', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/ALFA-SEGURADORA.png', 0, 'attachment', 'image/png', 0),
(115, 1, '2022-10-24 11:45:06', '2022-10-24 14:45:06', '', 'ALFA SEGURADORA@2x', '', 'inherit', 'open', 'closed', '', 'alfa-seguradora2x', '', '', '2022-10-24 11:45:06', '2022-10-24 14:45:06', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/ALFA-SEGURADORA@2x.png', 0, 'attachment', 'image/png', 0),
(116, 1, '2022-10-24 11:45:07', '2022-10-24 14:45:07', '', 'Banco Alfa', '', 'inherit', 'open', 'closed', '', 'banco-alfa', '', '', '2022-10-24 11:45:07', '2022-10-24 14:45:07', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Banco-Alfa.png', 0, 'attachment', 'image/png', 0),
(117, 1, '2022-10-24 11:45:08', '2022-10-24 14:45:08', '', 'Banco Alfa@2x', '', 'inherit', 'open', 'closed', '', 'banco-alfa2x', '', '', '2022-10-24 11:45:08', '2022-10-24 14:45:08', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Banco-Alfa@2x.png', 0, 'attachment', 'image/png', 0),
(118, 1, '2022-10-24 11:45:08', '2022-10-24 14:45:08', '', 'BERKLEY', '', 'inherit', 'open', 'closed', '', 'berkley', '', '', '2022-10-24 11:45:08', '2022-10-24 14:45:08', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/BERKLEY.png', 0, 'attachment', 'image/png', 0),
(119, 1, '2022-10-24 11:45:09', '2022-10-24 14:45:09', '', 'BERKLEY@2x', '', 'inherit', 'open', 'closed', '', 'berkley2x', '', '', '2022-10-24 11:45:09', '2022-10-24 14:45:09', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/BERKLEY@2x.png', 0, 'attachment', 'image/png', 0),
(120, 1, '2022-10-24 11:45:10', '2022-10-24 14:45:10', '', 'BSE', '', 'inherit', 'open', 'closed', '', 'bse', '', '', '2022-10-24 11:45:10', '2022-10-24 14:45:10', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/BSE.png', 0, 'attachment', 'image/png', 0),
(121, 1, '2022-10-24 11:45:10', '2022-10-24 14:45:10', '', 'BSE@2x', '', 'inherit', 'open', 'closed', '', 'bse2x', '', '', '2022-10-24 11:45:10', '2022-10-24 14:45:10', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/BSE@2x.png', 0, 'attachment', 'image/png', 0),
(122, 1, '2022-10-24 11:45:11', '2022-10-24 14:45:11', '', 'CHUBB', '', 'inherit', 'open', 'closed', '', 'chubb', '', '', '2022-10-24 11:45:11', '2022-10-24 14:45:11', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/CHUBB.png', 0, 'attachment', 'image/png', 0),
(123, 1, '2022-10-24 11:45:11', '2022-10-24 14:45:11', '', 'CHUBB@2x', '', 'inherit', 'open', 'closed', '', 'chubb2x', '', '', '2022-10-24 11:45:11', '2022-10-24 14:45:11', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/CHUBB@2x.png', 0, 'attachment', 'image/png', 0),
(124, 1, '2022-10-24 11:45:12', '2022-10-24 14:45:12', '', 'f2be4fdccb71ff923ed513e031c7f3a4', '', 'inherit', 'open', 'closed', '', 'f2be4fdccb71ff923ed513e031c7f3a4', '', '', '2022-10-24 11:45:12', '2022-10-24 14:45:12', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/f2be4fdccb71ff923ed513e031c7f3a4.png', 0, 'attachment', 'image/png', 0),
(125, 1, '2022-10-24 11:45:13', '2022-10-24 14:45:13', '', 'f2be4fdccb71ff923ed513e031c7f3a4@2x', '', 'inherit', 'open', 'closed', '', 'f2be4fdccb71ff923ed513e031c7f3a42x', '', '', '2022-10-24 11:45:13', '2022-10-24 14:45:13', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/f2be4fdccb71ff923ed513e031c7f3a4@2x.png', 0, 'attachment', 'image/png', 0),
(126, 1, '2022-10-24 11:45:14', '2022-10-24 14:45:14', '', 'Fundo-Equipe', '', 'inherit', 'open', 'closed', '', 'fundo-equipe', '', '', '2022-10-24 11:45:14', '2022-10-24 14:45:14', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Fundo-Equipe.png', 0, 'attachment', 'image/png', 0),
(127, 1, '2022-10-24 11:45:16', '2022-10-24 14:45:16', '', 'Fundo-Equipe@2x', '', 'inherit', 'open', 'closed', '', 'fundo-equipe2x', '', '', '2022-10-24 11:45:16', '2022-10-24 14:45:16', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Fundo-Equipe@2x.png', 0, 'attachment', 'image/png', 0),
(128, 1, '2022-10-24 11:45:21', '2022-10-24 14:45:21', '', 'GBoex', '', 'inherit', 'open', 'closed', '', 'gboex', '', '', '2022-10-24 11:45:21', '2022-10-24 14:45:21', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/GBoex.png', 0, 'attachment', 'image/png', 0),
(129, 1, '2022-10-24 11:45:22', '2022-10-24 14:45:22', '', 'GBoex@2x', '', 'inherit', 'open', 'closed', '', 'gboex2x', '', '', '2022-10-24 11:45:22', '2022-10-24 14:45:22', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/GBoex@2x.png', 0, 'attachment', 'image/png', 0),
(130, 1, '2022-10-24 11:45:23', '2022-10-24 14:45:23', '', 'GolderCross', '', 'inherit', 'open', 'closed', '', 'goldercross', '', '', '2022-10-24 11:45:23', '2022-10-24 14:45:23', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/GolderCross.png', 0, 'attachment', 'image/png', 0),
(131, 1, '2022-10-24 11:45:23', '2022-10-24 14:45:23', '', 'GolderCross@2x', '', 'inherit', 'open', 'closed', '', 'goldercross2x', '', '', '2022-10-24 11:45:23', '2022-10-24 14:45:23', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/GolderCross@2x.png', 0, 'attachment', 'image/png', 0),
(132, 1, '2022-10-24 11:45:24', '2022-10-24 14:45:24', '', 'HDI', '', 'inherit', 'open', 'closed', '', 'hdi-2', '', '', '2022-10-24 11:45:24', '2022-10-24 14:45:24', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/HDI.png', 0, 'attachment', 'image/png', 0),
(133, 1, '2022-10-24 11:45:24', '2022-10-24 14:45:24', '', 'HDI@2x', '', 'inherit', 'open', 'closed', '', 'hdi2x', '', '', '2022-10-24 11:45:24', '2022-10-24 14:45:24', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/HDI@2x.png', 0, 'attachment', 'image/png', 0),
(134, 1, '2022-10-24 11:45:25', '2022-10-24 14:45:25', '', 'Imagem-Banner 01', '', 'inherit', 'open', 'closed', '', 'imagem-banner-01', '', '', '2022-10-24 11:45:25', '2022-10-24 14:45:25', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Imagem-Banner-01.png', 0, 'attachment', 'image/png', 0),
(135, 1, '2022-10-24 11:45:28', '2022-10-24 14:45:28', '', 'Imagem-Banner 01@2x', '', 'inherit', 'open', 'closed', '', 'imagem-banner-012x', '', '', '2022-10-24 11:45:28', '2022-10-24 14:45:28', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Imagem-Banner-01@2x.png', 0, 'attachment', 'image/png', 0),
(136, 1, '2022-10-24 11:45:32', '2022-10-24 14:45:32', '', 'Imagem-Banner 02', '', 'inherit', 'open', 'closed', '', 'imagem-banner-02', '', '', '2022-10-24 11:45:32', '2022-10-24 14:45:32', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Imagem-Banner-02.png', 0, 'attachment', 'image/png', 0),
(137, 1, '2022-10-24 11:45:35', '2022-10-24 14:45:35', '', 'Imagem-Banner 02@2x', '', 'inherit', 'open', 'closed', '', 'imagem-banner-022x', '', '', '2022-10-24 11:45:35', '2022-10-24 14:45:35', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Imagem-Banner-02@2x.png', 0, 'attachment', 'image/png', 0),
(138, 1, '2022-10-24 11:45:40', '2022-10-24 14:45:40', '', 'JNS', '', 'inherit', 'open', 'closed', '', 'jns', '', '', '2022-10-24 11:45:40', '2022-10-24 14:45:40', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/JNS.png', 0, 'attachment', 'image/png', 0),
(139, 1, '2022-10-24 11:45:41', '2022-10-24 14:45:41', '', 'JNS@2x', '', 'inherit', 'open', 'closed', '', 'jns2x', '', '', '2022-10-24 11:45:41', '2022-10-24 14:45:41', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/JNS@2x.png', 0, 'attachment', 'image/png', 0),
(140, 1, '2022-10-24 11:45:41', '2022-10-24 14:45:41', '', 'Mapa', '', 'inherit', 'open', 'closed', '', 'mapa', '', '', '2022-10-24 11:45:41', '2022-10-24 14:45:41', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Mapa.png', 0, 'attachment', 'image/png', 0),
(141, 1, '2022-10-24 11:45:43', '2022-10-24 14:45:43', '', 'Mapa@2x', '', 'inherit', 'open', 'closed', '', 'mapa2x', '', '', '2022-10-24 11:45:43', '2022-10-24 14:45:43', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Mapa@2x.png', 0, 'attachment', 'image/png', 0),
(142, 1, '2022-10-24 11:45:44', '2022-10-24 14:45:44', '', 'Mitsui', '', 'inherit', 'open', 'closed', '', 'mitsui', '', '', '2022-10-24 11:45:44', '2022-10-24 14:45:44', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Mitsui.png', 0, 'attachment', 'image/png', 0),
(143, 1, '2022-10-24 11:45:45', '2022-10-24 14:45:45', '', 'Mitsui@2x', '', 'inherit', 'open', 'closed', '', 'mitsui2x', '', '', '2022-10-24 11:45:45', '2022-10-24 14:45:45', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/Mitsui@2x.png', 0, 'attachment', 'image/png', 0),
(144, 1, '2022-10-24 11:45:46', '2022-10-24 14:45:46', '', 'SABEMI', '', 'inherit', 'open', 'closed', '', 'sabemi', '', '', '2022-10-24 11:45:46', '2022-10-24 14:45:46', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/SABEMI.png', 0, 'attachment', 'image/png', 0),
(145, 1, '2022-10-24 11:45:46', '2022-10-24 14:45:46', '', 'SABEMI@2x', '', 'inherit', 'open', 'closed', '', 'sabemi2x', '', '', '2022-10-24 11:45:46', '2022-10-24 14:45:46', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/SABEMI@2x.png', 0, 'attachment', 'image/png', 0),
(146, 1, '2022-10-24 11:45:47', '2022-10-24 14:45:47', '', 'SOMPO', '', 'inherit', 'open', 'closed', '', 'sompo', '', '', '2022-10-24 11:45:47', '2022-10-24 14:45:47', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/SOMPO.png', 0, 'attachment', 'image/png', 0),
(147, 1, '2022-10-24 11:45:47', '2022-10-24 14:45:47', '', 'SOMPO@2x', '', 'inherit', 'open', 'closed', '', 'sompo2x', '', '', '2022-10-24 11:45:47', '2022-10-24 14:45:47', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/SOMPO@2x.png', 0, 'attachment', 'image/png', 0),
(148, 1, '2022-10-24 11:45:48', '2022-10-24 14:45:48', '', 'SulAmérica', '', 'inherit', 'open', 'closed', '', 'sulamerica', '', '', '2022-10-24 11:45:48', '2022-10-24 14:45:48', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/SulAmérica.png', 0, 'attachment', 'image/png', 0),
(149, 1, '2022-10-24 11:45:49', '2022-10-24 14:45:49', '', 'SulAmérica@2x', '', 'inherit', 'open', 'closed', '', 'sulamerica2x', '', '', '2022-10-24 11:45:49', '2022-10-24 14:45:49', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/SulAmérica@2x.png', 0, 'attachment', 'image/png', 0),
(150, 1, '2022-10-24 11:45:49', '2022-10-24 14:45:49', '', 'ZURICH', '', 'inherit', 'open', 'closed', '', 'zurich', '', '', '2022-10-24 11:45:49', '2022-10-24 14:45:49', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/ZURICH.png', 0, 'attachment', 'image/png', 0),
(151, 1, '2022-10-24 11:45:50', '2022-10-24 14:45:50', '', 'ZURICH@2x', '', 'inherit', 'open', 'closed', '', 'zurich2x', '', '', '2022-10-24 11:45:50', '2022-10-24 14:45:50', '', 89, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/ZURICH@2x.png', 0, 'attachment', 'image/png', 0),
(152, 1, '2022-10-24 11:46:54', '2022-10-24 14:46:54', '', 'Zurich', '', 'draft', 'closed', 'closed', '', 'zurich', '', '', '2022-10-26 10:24:44', '2022-10-26 13:24:44', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=152', 0, 'clientes', '', 0),
(153, 1, '2022-10-24 11:48:28', '2022-10-24 14:48:28', '', 'Sompo', '', 'draft', 'closed', 'closed', '', 'sompo', '', '', '2022-10-26 10:24:40', '2022-10-26 13:24:40', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=153', 0, 'clientes', '', 0),
(154, 1, '2022-10-24 11:48:43', '2022-10-24 14:48:43', '', 'SulAmérica', '', 'draft', 'closed', 'closed', '', 'sulamerica', '', '', '2022-10-26 10:24:34', '2022-10-26 13:24:34', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=154', 0, 'clientes', '', 0),
(155, 1, '2022-10-24 11:49:02', '2022-10-24 14:49:02', '', 'Sabemi', '', 'draft', 'closed', 'closed', '', 'sabemi', '', '', '2022-10-26 10:24:27', '2022-10-26 13:24:27', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=155', 0, 'clientes', '', 0),
(156, 1, '2022-10-24 11:49:26', '2022-10-24 14:49:26', '', 'JNS Seguros', '', 'draft', 'closed', 'closed', '', 'jns-seguros', '', '', '2022-10-26 10:24:22', '2022-10-26 13:24:22', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=156', 0, 'clientes', '', 0),
(157, 1, '2022-10-24 11:49:48', '2022-10-24 14:49:48', '', 'Mitsui', '', 'draft', 'closed', 'closed', '', 'mitsui', '', '', '2022-10-26 10:24:17', '2022-10-26 13:24:17', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=157', 0, 'clientes', '', 0),
(158, 1, '2022-10-24 11:50:05', '2022-10-24 14:50:05', '', 'Alfa Seguradora', '', 'draft', 'closed', 'closed', '', 'alfa-seguradora', '', '', '2022-10-26 10:24:10', '2022-10-26 13:24:10', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=158', 0, 'clientes', '', 0),
(159, 1, '2022-10-24 11:50:19', '2022-10-24 14:50:19', '', 'GBoex', '', 'draft', 'closed', 'closed', '', 'gboex', '', '', '2022-10-26 10:24:05', '2022-10-26 13:24:05', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=159', 0, 'clientes', '', 0),
(160, 1, '2022-10-24 11:50:32', '2022-10-24 14:50:32', '', 'CHUBB', '', 'draft', 'closed', 'closed', '', 'chubb', '', '', '2022-10-26 10:23:54', '2022-10-26 13:23:54', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=160', 0, 'clientes', '', 0),
(161, 1, '2022-10-24 11:50:44', '2022-10-24 14:50:44', '', 'BSE', '', 'draft', 'closed', 'closed', '', 'bse', '', '', '2022-10-26 10:23:58', '2022-10-26 13:23:58', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=161', 0, 'clientes', '', 0),
(162, 1, '2022-10-24 11:51:02', '2022-10-24 14:51:02', '', 'Berkley', '', 'draft', 'closed', 'closed', '', 'berkley', '', '', '2022-10-26 10:22:28', '2022-10-26 13:22:28', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=162', 0, 'clientes', '', 0),
(163, 1, '2022-10-24 11:51:19', '2022-10-24 14:51:19', '', 'Akad Seguros', '', 'draft', 'closed', 'closed', '', 'akad-seguros', '', '', '2022-10-26 10:22:21', '2022-10-26 13:22:21', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=163', 0, 'clientes', '', 0),
(165, 1, '2022-10-24 11:52:40', '2022-10-24 14:52:40', '', 'Banco Alfa', '', 'draft', 'closed', 'closed', '', 'banco-alfa', '', '', '2022-11-03 14:22:52', '2022-11-03 17:22:52', '', 0, 'https://localhost/torellybastos.com.br/?post_type=clientes&#038;p=165', 0, 'clientes', '', 0),
(166, 1, '2022-10-25 16:59:28', '2022-10-25 19:59:28', 'Graduado pela Universidade Luterana do Brasil; Pós-graduado no MBA em Gestão Empresarial pela FGV; formação e participação em diversos cursos e programas na área de direito civil e processo civil, seguros, provisionamento e contingências judiciais, compliance, gestão e administração de escritórios de advocacia, gestão de pessoas, liderança, finanças corporativas, entre outros, painelista e mediador de eventos, Membro da Comissão Especial de Seguros e Previdência Complementar da OAB/RS, sendo seu Vice-Presidente entre 2015 e 2018, Membro da Comissão Especial da Advocacia Corporativa da OAB/RS, Membro da Comissão Especial de Proteção de Dados e Privacidade da OAB/RS e Membro da AIDA BRASIL - Associação Internacional de Direito do Seguro, Seção Brasileira.', 'Eduardo Rodrigues Silva', '', 'publish', 'closed', 'closed', '', 'eduardo-rodrigues-silva', '', '', '2022-10-28 11:24:52', '2022-10-28 14:24:52', '', 0, 'https://localhost/torellybastos.com.br/?post_type=equipe&#038;p=166', 0, 'equipe', '', 0),
(167, 1, '2022-10-25 15:19:43', '2022-10-25 18:19:43', 'Advogado militante na área de seguros e previdência complementar, foi Assessor Jurídico de MBM Seguro de Pessoas entre 2005 e 2007 e seu Gerente Jurídico entre 2008 e 2012. Bacharel em Direito e Especialista em Direito, Mercado e Economia pela Pontifícia Universidade Católica do RS – PUCRS; Pós-graduado, lato sensu, em Gestão de Departamentos Jurídicos pela Universidade do Vale do Rio dos Sinos – UNISINOS; Mestre em Direito da Empresa e dos Negócios pela Universidade do Vale do Rio dos Sinos – UNISINOS com a realização de disciplinas na Washington University in Saint Louis - USA; Especialista en Derecho de Seguros por la Universidad de Salamanca – España; Membro da Seção Brasileira da Association Internationale de Droit des Assurances – AIDA, Presidente del Grupo de Trabajo de Automotores del Comité Ibero-Latinoamericano – CILA/AIDA; Membro Fundador da Comissão Especial de Seguros e Previdência Complementar da OAB/RS, tendo sido seu Presidente entre os anos de 2014 e 2018; Painelista e debatedor em eventos sobre o tema, bem como Professor Titular na UniRitter - Laureate International Universities e convidado em cursos de especialização em diversas instituições de ensino superior, entre elas a UNISINOS, CESUSC e PUCRS.v', 'Marcelo Barreto Leal', '', 'publish', 'closed', 'closed', '', 'marcelo-barreto-leal', '', '', '2022-10-28 11:25:12', '2022-10-28 14:25:12', '', 0, 'https://localhost/torellybastos.com.br/?post_type=equipe&#038;p=167', 0, 'equipe', '', 0),
(168, 1, '2022-10-25 14:21:00', '2022-10-25 17:21:00', 'Graduada em Direito pela Universidade do Vale do Rio dos Sinos – UNISINOS/RS. Especialista em Direito dos Seguros pela Fundação Escola Superior do Ministério Público – FMP/RS.', 'Luana Scheid Dahinten', '', 'draft', 'closed', 'closed', '', 'luana-scheid-dahinten', '', '', '2022-11-09 10:55:44', '2022-11-09 13:55:44', '', 0, 'https://localhost/torellybastos.com.br/?post_type=equipe&#038;p=168', 0, 'equipe', '', 0),
(169, 1, '2022-10-25 13:22:55', '2022-10-25 16:22:55', 'Graduado em Direito pela Pontifícia Universidade Católica do Rio Grande do Sul - PUCRS. Especialista em Direito dos Seguros pela Fundação Escola Superior do Ministério Público – FMP/RS. Membro da AIDA BRASIL - Associação Internacional de Direito do Seguro, Seção Brasileira.', 'Vinicius de Lima Pellin', '', 'publish', 'closed', 'closed', '', 'vinicius-de-lima-pellin', '', '', '2022-10-28 11:25:57', '2022-10-28 14:25:57', '', 0, 'https://localhost/torellybastos.com.br/?post_type=equipe&#038;p=169', 0, 'equipe', '', 0),
(170, 1, '2022-10-24 12:39:23', '2022-10-24 15:39:23', '', 'AMBIENTAL', '', 'inherit', 'closed', 'closed', '', '75-autosave-v1', '', '', '2022-10-24 12:39:23', '2022-10-24 15:39:23', '', 75, 'https://localhost/torellybastos.com.br/?p=170', 0, 'revision', '', 0),
(172, 1, '2022-10-24 12:49:06', '2022-10-24 15:49:06', '', 'TRIBUTÁRIO', '', 'publish', 'closed', 'closed', '', 'tributario', '', '', '2022-10-24 12:49:06', '2022-10-24 15:49:06', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=172', 0, 'areas', '', 0),
(173, 1, '2022-10-24 12:49:52', '2022-10-24 15:49:52', '', 'DIREITO BANCÁRIO', '', 'publish', 'closed', 'closed', '', 'direito-bancario', '', '', '2022-10-24 12:49:52', '2022-10-24 15:49:52', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=173', 0, 'areas', '', 0),
(174, 1, '2022-10-24 12:50:11', '2022-10-24 15:50:11', '', 'RELAÇÕES DE CONSUMO', '', 'publish', 'closed', 'closed', '', 'relacoes-de-consumo', '', '', '2022-10-24 12:50:11', '2022-10-24 15:50:11', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=174', 0, 'areas', '', 0),
(175, 1, '2022-10-24 12:50:37', '2022-10-24 15:50:37', '', 'RECUPERAÇÃO JUDICIAL', '', 'publish', 'closed', 'closed', '', 'recuperacao-judicial', '', '', '2022-10-24 12:50:37', '2022-10-24 15:50:37', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=175', 0, 'areas', '', 0),
(176, 1, '2022-10-24 12:51:25', '2022-10-24 15:51:25', '', 'RESPONSABILIDADE CIVIL', '', 'publish', 'closed', 'closed', '', 'responsabilidade-civil', '', '', '2022-10-24 12:51:25', '2022-10-24 15:51:25', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=176', 0, 'areas', '', 0),
(177, 1, '2022-10-24 12:52:03', '2022-10-24 15:52:03', '', 'PREVIDÊNCIA PRIVADA', '', 'publish', 'closed', 'closed', '', 'previdencia-privada', '', '', '2022-10-24 12:52:03', '2022-10-24 15:52:03', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=177', 0, 'areas', '', 0),
(178, 1, '2022-10-24 12:52:41', '2022-10-24 15:52:41', '', 'SEGUROS', '', 'publish', 'closed', 'closed', '', 'seguros', '', '', '2022-10-26 11:14:24', '2022-10-26 14:14:24', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=178', 0, 'areas', '', 0),
(179, 1, '2022-10-24 12:54:58', '2022-10-24 15:54:58', '', 'PRODUTOS INOVADORES', '', 'inherit', 'closed', 'closed', '', '74-autosave-v1', '', '', '2022-10-24 12:54:58', '2022-10-24 15:54:58', '', 74, 'https://localhost/torellybastos.com.br/?p=179', 0, 'revision', '', 0),
(180, 1, '2022-10-24 12:56:21', '2022-10-24 15:56:21', '', 'NÚCLEO DE ACORDOS', '', 'publish', 'closed', 'closed', '', 'nucleo-de-acordos', '', '', '2022-10-24 12:56:21', '2022-10-24 15:56:21', '', 0, 'https://localhost/torellybastos.com.br/?post_type=gestao&#038;p=180', 0, 'gestao', '', 0),
(181, 1, '2022-10-24 12:56:49', '2022-10-24 15:56:49', '', 'NÚCLEO TÉCNICO DE CRIAÇÃO', '', 'publish', 'closed', 'closed', '', 'nucleo-tecnico-de-criacao', '', '', '2022-10-24 12:56:49', '2022-10-24 15:56:49', '', 0, 'https://localhost/torellybastos.com.br/?post_type=gestao&#038;p=181', 0, 'gestao', '', 0),
(182, 1, '2022-10-24 13:01:28', '2022-10-24 16:01:28', '', 'CONTENCIOSO EXCLUSIVO ESPECIALIZADO', '', 'publish', 'closed', 'closed', '', 'contencioso-exclusivo-especializado', '', '', '2022-10-24 13:01:28', '2022-10-24 16:01:28', '', 0, 'https://localhost/torellybastos.com.br/?post_type=gestao&#038;p=182', 0, 'gestao', '', 0),
(183, 1, '2022-10-24 13:02:10', '2022-10-24 16:02:10', '', 'FERRAMENTAS CUSTOMIZÁVEIS', '', 'publish', 'closed', 'closed', '', 'atendimento-personalizado', '', '', '2022-10-24 13:03:25', '2022-10-24 16:03:25', '', 0, 'https://localhost/torellybastos.com.br/?post_type=gestao&#038;p=183', 0, 'gestao', '', 0),
(184, 1, '2022-10-24 13:03:51', '2022-10-24 16:03:51', '', 'ATENDIMENTO PERSONALIZADO', '', 'publish', 'closed', 'closed', '', 'atendimento-personalizado-2', '', '', '2022-10-24 13:03:51', '2022-10-24 16:03:51', '', 0, 'https://localhost/torellybastos.com.br/?post_type=gestao&#038;p=184', 0, 'gestao', '', 0),
(186, 1, '2022-10-24 13:22:29', '2022-10-24 16:22:29', '', '1657376859522', '', 'inherit', 'open', 'closed', '', '1657376859522-5', '', '', '2022-10-24 13:22:29', '2022-10-24 16:22:29', '', 166, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/1657376859522-5.png', 0, 'attachment', 'image/png', 0),
(188, 1, '2022-10-26 10:27:46', '2022-10-26 13:27:46', '', 'View_TRB_005_22_Banner-Site_001d', '', 'inherit', 'open', 'closed', '', 'view_trb_005_22_banner-site_001d', '', '', '2022-10-26 10:27:46', '2022-10-26 13:27:46', '', 43, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/View_TRB_005_22_Banner-Site_001d.png', 0, 'attachment', 'image/png', 0),
(189, 1, '2022-10-26 10:52:45', '2022-10-26 13:52:45', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Topbar', 'topbar', 'publish', 'closed', 'closed', '', 'field_63593b62b35c9', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 11, 'https://localhost/torellybastos.com.br/?post_type=acf-field&p=189', 0, 'acf-field', '', 0),
(190, 1, '2022-10-26 10:52:45', '2022-10-26 13:52:45', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:0:"";}', 'Topbar', 'topbar', 'publish', 'closed', 'closed', '', 'field_63593b78b35ca', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 11, 'https://localhost/torellybastos.com.br/?post_type=acf-field&p=190', 1, 'acf-field', '', 0),
(191, 1, '2022-10-26 10:52:45', '2022-10-26 13:52:45', 'a:15:{s:4:"type";s:12:"font-awesome";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"icon_sets";a:3:{i:0;s:5:"solid";i:1;s:7:"regular";i:2;s:6:"brands";}s:15:"custom_icon_set";s:0:"";s:13:"default_label";s:0:"";s:13:"default_value";s:0:"";s:11:"save_format";s:7:"element";s:10:"allow_null";i:0;s:12:"show_preview";i:1;s:10:"enqueue_fa";i:0;s:15:"fa_live_preview";s:0:"";s:7:"choices";a:0:{}}', 'Icone', 'icone', 'publish', 'closed', 'closed', '', 'field_63593b95b35cb', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 190, 'https://localhost/torellybastos.com.br/?post_type=acf-field&p=191', 0, 'acf-field', '', 0),
(192, 1, '2022-10-26 10:52:45', '2022-10-26 13:52:45', 'a:6:{s:4:"type";s:4:"link";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";}', 'Url', 'url', 'publish', 'closed', 'closed', '', 'field_63593ba0b35cc', '', '', '2022-10-26 10:52:45', '2022-10-26 13:52:45', '', 190, 'https://localhost/torellybastos.com.br/?post_type=acf-field&p=192', 1, 'acf-field', '', 0),
(193, 1, '2022-10-26 10:57:41', '2022-10-26 13:57:41', '', 'Áreas de Atuação', '', 'publish', 'closed', 'closed', '', 'areas-de-atuacao', '', '', '2022-10-26 10:57:41', '2022-10-26 13:57:41', '', 0, 'https://localhost/torellybastos.com.br/?p=193', 3, 'nav_menu_item', '', 0),
(194, 1, '2022-10-26 11:48:08', '2022-10-26 13:59:30', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2022-10-26 11:48:08', '2022-10-26 14:48:08', '', 0, 'https://localhost/torellybastos.com.br/?p=194', 1, 'nav_menu_item', '', 0),
(195, 1, '2022-10-26 11:48:08', '2022-10-26 13:59:30', '', 'Contato', '', 'publish', 'closed', 'closed', '', 'contato', '', '', '2022-10-26 11:48:08', '2022-10-26 14:48:08', '', 0, 'https://localhost/torellybastos.com.br/?p=195', 2, 'nav_menu_item', '', 0),
(196, 1, '2022-10-26 11:48:08', '2022-10-26 13:59:30', '', 'Política de Privacidade', '', 'publish', 'closed', 'closed', '', 'politica-de-privacidade', '', '', '2022-10-26 11:48:08', '2022-10-26 14:48:08', '', 0, 'https://localhost/torellybastos.com.br/?p=196', 3, 'nav_menu_item', '', 0),
(199, 1, '2022-10-26 11:09:35', '2022-10-26 14:09:35', '', 'TESTE', '', 'trash', 'closed', 'closed', '', 'teste__trashed', '', '', '2022-10-26 11:09:47', '2022-10-26 14:09:47', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=199', 0, 'areas', '', 0),
(200, 1, '2022-10-26 11:44:16', '2022-10-26 14:34:14', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog-2', '', '', '2022-10-26 11:44:16', '2022-10-26 14:44:16', '', 0, 'https://localhost/torellybastos.com.br/?p=200', 4, 'nav_menu_item', '', 0),
(201, 1, '2022-10-26 11:44:16', '2022-10-26 14:34:14', '', 'Áreas de Atução', '', 'publish', 'closed', 'closed', '', 'areas-de-atucao', '', '', '2022-10-26 11:44:16', '2022-10-26 14:44:16', '', 0, 'https://localhost/torellybastos.com.br/?p=201', 3, 'nav_menu_item', '', 0),
(202, 1, '2022-10-26 11:44:16', '2022-10-26 14:34:14', '', 'Contato', '', 'publish', 'closed', 'closed', '', 'contato-2', '', '', '2022-10-26 11:44:16', '2022-10-26 14:44:16', '', 0, 'https://localhost/torellybastos.com.br/?p=202', 5, 'nav_menu_item', '', 0),
(203, 1, '2022-10-28 11:18:01', '2022-10-28 14:18:01', '', 'View_TRB_005_22_Banner-Site_001c (1)', '', 'inherit', 'open', 'closed', '', 'view_trb_005_22_banner-site_001c-1', '', '', '2022-10-28 11:18:01', '2022-10-28 14:18:01', '', 84, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/10/View_TRB_005_22_Banner-Site_001c-1.png', 0, 'attachment', 'image/png', 0),
(205, 1, '2022-11-03 14:22:01', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-11-03 14:22:01', '0000-00-00 00:00:00', '', 0, 'https://localhost/torellybastos.com.br/?p=205', 0, 'post', '', 0),
(206, 1, '2022-11-03 14:23:29', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-11-03 14:23:29', '0000-00-00 00:00:00', '', 0, 'https://localhost/torellybastos.com.br/?p=206', 0, 'post', '', 0),
(207, 1, '2022-11-03 14:24:24', '0000-00-00 00:00:00', '', 'Saúde Suplementar', '', 'draft', 'closed', 'closed', '', '', '', '', '2022-11-03 14:24:24', '2022-11-03 17:24:24', '', 0, 'https://localhost/torellybastos.com.br/?post_type=areas&#038;p=207', 0, 'areas', '', 0),
(208, 1, '2022-11-04 11:59:54', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2022-11-04 11:59:54', '0000-00-00 00:00:00', '', 0, 'https://localhost/torellybastos.com.br/?post_type=banners&p=208', 0, 'banners', '', 0),
(209, 1, '2022-11-09 10:55:12', '2022-11-09 13:55:12', '', 'AHA_2015_003_0766', '', 'inherit', 'open', 'closed', '', 'aha_2015_003_0766', '', '', '2022-11-09 10:55:19', '2022-11-09 13:55:19', '', 6, 'http://localhost/torellybastos.com.br/wp-content/uploads/2022/11/AHA_2015_003_0766.jpg', 0, 'attachment', 'image/jpeg', 0),
(210, 1, '2022-11-09 10:55:24', '2022-11-09 13:55:24', '<!-- wp:paragraph -->\n<p>Experiência,<br>visão<br>estratégica<br>e olhar para<br>o futuro</p>\n<!-- /wp:paragraph -->', 'Home', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2022-11-09 10:55:24', '2022-11-09 13:55:24', '', 6, 'https://localhost/torellybastos.com.br/?p=210', 0, 'revision', '', 0),
(211, 1, '2022-11-09 16:17:33', '0000-00-00 00:00:00', '{"nav_menu_item[-5185516896957374000]":{"value":{"object_id":6,"object":"page","menu_item_parent":0,"position":6,"type":"post_type","title":"Home","url":"https:\\/\\/localhost\\/torellybastos.com.br\\/","target":"","attr_title":"","description":"","classes":"","xfn":"","status":"publish","original_title":"Home","nav_menu_term_id":3,"_invalid":false,"type_label":"P\\u00e1gina principal"},"type":"nav_menu_item","user_id":1,"date_modified_gmt":"2022-11-09 19:17:33"}}', '', '', 'auto-draft', 'closed', 'closed', '', '926d67a9-65d6-4413-a275-1fcaf9760e14', '', '', '2022-11-09 16:17:33', '0000-00-00 00:00:00', '', 0, 'https://localhost/torellybastos.com.br/?p=211', 0, 'customize_changeset', '', 0) ;

#
# Fim do conteúdo da tabela `wp_posts`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_term_relationships` existente
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Estrutura da tabela `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 5, 0),
(8, 2, 0),
(32, 3, 0),
(33, 3, 0),
(37, 4, 0),
(38, 4, 0),
(39, 1, 0),
(193, 4, 0),
(194, 6, 0),
(195, 6, 0),
(196, 6, 0),
(197, 1, 0),
(200, 3, 0),
(201, 3, 0),
(202, 3, 0) ;

#
# Fim do conteúdo da tabela `wp_term_relationships`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_term_taxonomy` existente
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Estrutura da tabela `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'wp_theme', '', 0, 1),
(3, 3, 'nav_menu', '', 0, 5),
(4, 4, 'nav_menu', '', 0, 3),
(5, 5, 'post_tag', '', 0, 1),
(6, 6, 'nav_menu', '', 0, 3) ;

#
# Fim do conteúdo da tabela `wp_term_taxonomy`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_termmeta` existente
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Estrutura da tabela `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_termmeta`
#

#
# Fim do conteúdo da tabela `wp_termmeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_terms` existente
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Estrutura da tabela `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Sem categoria', 'sem-categoria', 0),
(2, 's3', 's3', 0),
(3, 'Menu Princial', 'menu-princial', 0),
(4, 'Menu Footer 1', 'menu-footer-1', 0),
(5, 'Teste', 'teste', 0),
(6, 'Menu Footer 2', 'menu-footer-2', 0) ;

#
# Fim do conteúdo da tabela `wp_terms`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_usermeta` existente
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Estrutura da tabela `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:3:{s:64:"2a0e246251ef2fed1e7ca1286e8fa4eebf5787dd6802f7838146622c3192607f";a:4:{s:10:"expiration";i:1668174853;s:2:"ip";s:13:"201.48.189.97";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36";s:5:"login";i:1668002053;}s:64:"7b78e1cadbcf486b406b8187a2acd0323e674c5a5e4ee7225e3d6470152bdf2b";a:4:{s:10:"expiration";i:1668194219;s:2:"ip";s:14:"177.74.142.123";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36";s:5:"login";i:1668021419;}s:64:"83e48542d43dc6936bbe49541e1c163502c37d19f7d339b14656c305dbacaf18";a:4:{s:10:"expiration";i:1668224603;s:2:"ip";s:15:"179.111.108.119";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36";s:5:"login";i:1668051803;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '205'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:13:"179.111.108.0";}'),
(19, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(20, 1, 'wp_user-settings-time', '1666622250'),
(21, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(22, 1, 'metaboxhidden_dashboard', 'a:5:{i:0;s:21:"dashboard_site_health";i:1;s:19:"dashboard_right_now";i:2;s:18:"dashboard_activity";i:3;s:21:"dashboard_quick_press";i:4;s:17:"dashboard_primary";}'),
(23, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(24, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(25, 1, 'nav_menu_recently_edited', '6'),
(26, 2, 'nickname', 'eduardo'),
(27, 2, 'first_name', 'Eduardo'),
(28, 2, 'last_name', 'Silva'),
(29, 2, 'description', ''),
(30, 2, 'rich_editing', 'true'),
(31, 2, 'syntax_highlighting', 'true'),
(32, 2, 'comment_shortcuts', 'false'),
(33, 2, 'admin_color', 'fresh'),
(34, 2, 'use_ssl', '0'),
(35, 2, 'show_admin_bar_front', 'true'),
(36, 2, 'locale', ''),
(37, 2, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(38, 2, 'wp_user_level', '10'),
(39, 2, 'dismissed_wp_pointers', ''),
(41, 2, 'wp_dashboard_quick_press_last_post_id', '204'),
(42, 2, 'community-events-location', 'a:1:{s:2:"ip";s:12:"167.250.29.0";}'),
(43, 1, 'wp_persisted_preferences', 'a:2:{s:14:"core/edit-post";a:8:{s:12:"welcomeGuide";b:0;s:16:"hiddenBlockTypes";a:0:{}s:10:"editorMode";s:6:"visual";s:24:"preferredStyleVariations";a:0:{}s:14:"inactivePanels";a:0:{}s:10:"openPanels";a:3:{i:0;s:11:"post-status";i:1;s:24:"yoast-seo/document-panel";i:2;s:14:"featured-image";}s:17:"complementaryArea";s:18:"edit-post/document";s:26:"isComplementaryAreaVisible";b:1;}s:9:"_modified";s:24:"2022-11-03T17:23:32.632Z";}') ;

#
# Fim do conteúdo da tabela `wp_usermeta`
# --------------------------------------------------------



#
# Apagar qualquer tabela `wp_users` existente
#

DROP TABLE IF EXISTS `wp_users`;


#
# Estrutura da tabela `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Conteúdo da tabela `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$B3NNbZ/W8KsXHEISkFA9/k84xnbs/i.', 'admin', 'suporte@s3digital.com.br', 'http://localhost/torellybastos.com.br', '2022-10-18 16:00:16', '', 0, 'admin'),
(2, 'eduardo', '$P$B8Oz1UYj/aCQedIAj5.LE10Dya8qVu0', 'eduardo', 'eduardo@torellybastos.com.br', '', '2022-10-28 14:28:16', '1666967297:$P$BLs4GlDA.ZoxLKmkfXv3anVMA9/kf3/', 0, 'Eduardo Silva') ;

#
# Fim do conteúdo da tabela `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

